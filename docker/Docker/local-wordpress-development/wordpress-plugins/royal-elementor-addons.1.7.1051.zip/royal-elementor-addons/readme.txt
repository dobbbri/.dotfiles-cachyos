=== Royal Addons for Elementor – Addons and Templates Kit for Elementor ===
Contributors: wproyal, rubeushagrid13, cyberpinky, elementoraddonswpr, ggedenidze1982, wprduke
Tags: elementor, elementor templates, elementor addons, elementor widgets, header footer builder, elementor mega menu, elementor woocommerce builder, theme builder, header footer builder, elementor post grid, elementor product grid, addons for elementor
Stable tag: 1.7.1051
Requires at least: 5.0
Tested up to: 6.9.1
Requires PHP: 5.6
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Elementor templates, Header footer builder, Elementor Post Grid, Woocommerce Grid builder, Slider, Forms, Gallery, Nav menu addons, Elementor widgets. Just best elementor addons. Collection of unique addons for elementor. Elementor woocommerce builder & Elementor woocommerce templates. Elementor Mega Menu Builder.

== Description ==

**Royal Elementor addons** is the most versatile, intuitive, and easy to use [Popular Page Builder](https://wordpress.org/plugins/elementor/) extension. Our goal is to provide you with the tools to make things happen, efficiently, and fast compare to other elementor addons. Choosing us is not only a mindset, but it is also a requirement if you intend to gain an edge over your competitors when creating your website. The best part is that you can design anything **without having to touch a single line of code**.

Comes with **100+ Elementor addons, 150+ Elementor Templates KIT (Growing Each Week), Theme Builder, elementor Custom Widget Builder, WooCommerce Builder, Elementor Mega Menu Builder, Advanced Sticky Header, Header Footer Builder, Forms Builder, Advanced Filters (filter any CPT, taxonomies and metafields), AJAX Search, Popup Builder, Post Slider and Carousel, Product Slider and Carousel, Premade Widget Blocks & Extensions.** Creative and self-intuitive widgets to take your WordPress website to the next level. **All widgets are Free** and the Pro Version offers even more advanced functionality.

*Free and Pro functionalities are mixed in the Widget Demos below.*

✅[**Plugin Home Page**](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab)
✅[**Elementor Templates Home Page**](https://demosites.royal-elementor-addons.com/elementor-templates/?ref=rea-wpo-pp-details-tab)
✅[**Woocommerce Elementor Templates Demo Page**](https://demosites.royal-elementor-addons.com/elementor-templates/?ref=rea-wpo-pp-details-tab#filter:category-shop)

**Widget List:**

- [**Mega Menu with Off-Canvas mobile menu support**](https://royal-elementor-addons.com/elementor-mega-menu-widget/?ref=rea-wpo-pp-details-tab)
- [**Nav Menu**](https://royal-elementor-addons.com/elementor-menu-widget/?ref=rea-wpo-pp-details-tab)
- [**Post Grid**](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-blog-grid)
- [**Post Carousel**](https://royal-elementor-addons.com/elementor-grid-widget-examples/post-carousel-examples/?ref=rea-wpo-pp-details-tab#filter:category-portfolio-grid)
- [**Post Slider**](https://royal-elementor-addons.com/elementor-grid-widget-examples/post-slider-examples/?ref=rea-wpo-pp-details-tab)
- [**Advanced Filters (filter any CPT, taxonomies and metafields)**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/?ref=rea-wpo-pp-details-tab)
- [**Custom Widget Builder (build any type of elementor widgets for your projects)**](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab)
- [**Form Builder**](https://royal-elementor-addons.com/elementor-form-builder-widget/?ref=rea-wpo-pp-details-tab)
- [**WooCommerce Product Grid**](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-woo-grid)
- [**WooCommerce Product Carousel**](https://royal-elementor-addons.com/elementor-grid-widget-examples/product-carousel-examples/?ref=rea-wpo-pp-details-tab)
- [**WooCommerce Product Slider**](https://royal-elementor-addons.com/elementor-grid-widget-examples/product-slider-examples/?ref=rea-wpo-pp-details-tab#)
- [**Image Grid - Image Slider**](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-gallery-grid)
- [**Image Carousel**](https://royal-elementor-addons.com/elementor-grid-widget-examples/image-carousel-examples/?ref=rea-wpo-pp-details-tab)
- [**Magazine Grid**](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-magazine-grid)
- [**Advanced Slider - Carousel**](https://royal-elementor-addons.com/elementor-advanced-slider-widget/?ref=rea-wpo-pp-details-tab)
- [**Charts - Horizontal/Vertical, Line, Radar, Doughnut, Pie, Polar Area**](https://royal-elementor-addons.com/elementor-charts-widget/?ref=rea-wpo-pp-details-tab)
- [**Testimonial Slider**](https://royal-elementor-addons.com/elementor-testimonials-slider-widget/?ref=rea-wpo-pp-details-tab)
- [**Onepage Navigation**](https://royal-elementor-addons.com/elementor-one-page-navigation-widget/?ref=rea-wpo-pp-details-tab)
- [**Pricing Table**](https://royal-elementor-addons.com/elementor-pricing-table-widget/?ref=rea-wpo-pp-details-tab)
- [**Content Toggle**](https://royal-elementor-addons.com/elementor-content-toggle-widget/?ref=rea-wpo-pp-details-tab)
- [**Countdown Timer**](https://royal-elementor-addons.com/elementor-countdown-widget/?ref=rea-wpo-pp-details-tab)
- [**Progress Bar**](https://royal-elementor-addons.com/elementor-progress-bar-widget/?ref=rea-wpo-pp-details-tab)
- [**Tabs**](https://royal-elementor-addons.com/elementor-tabs-widget/?ref=rea-wpo-pp-details-tab)
- [**Advanced Text - Fancy Text**](https://royal-elementor-addons.com/elementor-advanced-text-widget/?ref=rea-wpo-pp-details-tab)
- [**Category Grid**](https://demosites.royal-elementor-addons.com/fashion-v1/?ref=rea-wpo-pp-details-tab#catgridprev)
- [**Flip Box**](https://royal-elementor-addons.com/elementor-flip-box-widget/?ref=rea-wpo-pp-details-tab) 
- [**Promo Box**](https://royal-elementor-addons.com/elementor-promo-box-widget/?ref=rea-wpo-pp-details-tab) 
- [**Before After Slider - Image comparison Slider**](https://royal-elementor-addons.com/elementor-before-after-widget/?ref=rea-wpo-pp-details-tab)
- [**Image Hotspots**](https://royal-elementor-addons.com/elementor-image-hotspot-widget/?ref=rea-wpo-pp-details-tab)
- [**Contact Form 7 Styler**](https://royal-elementor-addons.com/forms-widget/contact-form-7/?ref=rea-wpo-pp-details-tab)
- [**Ninja Forms Styler**](https://royal-elementor-addons.com/elementor-forms-widget/ninja-forms/?ref=rea-wpo-pp-details-tab)
- [**WP Forms Styler**](https://royal-elementor-addons.com/elementor-forms-widget/wp-forms/?ref=rea-wpo-pp-details-tab)
- [**Caldera Forms Styler**](https://royal-elementor-addons.com/elementor-forms-widget/caldera-forms/?ref=rea-wpo-pp-details-tab)
- [**MailChimp**](https://royal-elementor-addons.com/elementor-mailchimp-subscription-widget/?ref=rea-wpo-pp-details-tab)
- [**Content Ticker**](https://royal-elementor-addons.com/elementor-content-ticker-widget/?ref=rea-wpo-pp-details-tab)
- [**Button**](https://royal-elementor-addons.com/elementor-button-widget/?ref=rea-wpo-pp-details-tab)
- [**Dual Button**](https://royal-elementor-addons.com/elementor-button-widget/?ref=rea-wpo-pp-details-tab#dualbuttonsection)
- [**Team Member**](https://royal-elementor-addons.com/elementor-team-member-widget/?ref=rea-wpo-pp-details-tab)
- [**Google Maps**](https://royal-elementor-addons.com/elementor-google-maps-widget/?ref=rea-wpo-pp-details-tab)
- [**Price List**](https://royal-elementor-addons.com/elementor-price-list-widget/?ref=rea-wpo-pp-details-tab)
- [**Business Hours**](https://royal-elementor-addons.com/elementor-business-hours-widget/?ref=rea-wpo-pp-details-tab) 
- [**Sharing Buttons**](https://royal-elementor-addons.com/elementor-social-sharing-buttons-widget/?ref=rea-wpo-pp-details-tab)
- [**Search Form with Live Ajax Search**](https://royal-elementor-addons.com/elementor-search-widget/?ref=rea-wpo-pp-details-tab)
- [**Site Logo**](https://royal-elementor-addons.com/)
- [**Back to Top Button**](https://royal-elementor-addons.com/elementor-back-to-top-widget/?ref=rea-wpo-pp-details-tab)
- [**Phone Call Button**](https://royal-elementor-addons.com/elementor-phone-call-widget/?ref=rea-wpo-pp-details-tab)
- [**Lottie Animation**](https://royal-elementor-addons.com/elementor-lottie-animation-widget/?ref=rea-wpo-pp-details-tab)
- [**Timeline Widget**](https://royal-elementor-addons.com/elementor-timeline-widget/?ref=rea-wpo-pp-details-tab)
- [**Flip Carousel**](https://royal-elementor-addons.com/elementor-flip-carousel-widget/?ref=rea-wpo-pp-details-tab)
- [**Features List**](https://royal-elementor-addons.com/elementor-feature-list-widget/?ref=rea-wpo-pp-details-tab)
- [**Dual Color Heading**](https://royal-elementor-addons.com/elementor-dual-color-heading-widget/?ref=rea-wpo-pp-details-tab)
- [**Advanced Accordion with Search**](https://royal-elementor-addons.com/elementor-advanced-accordion-widget/?ref=rea-wpo-pp-details-tab)
- [**Image Accordion**](https://royal-elementor-addons.com/elementor-image-accordion-widget/?ref=rea-wpo-pp-details-tab)
- [**Page List for Mega Menu**](https://royal-elementor-addons.com/elementor-mega-menu-widget/?ref=rea-wpo-pp-details-tab)
- [**Data Table**](https://royal-elementor-addons.com/elementor-data-table-widget/?ref=rea-wpo-pp-details-tab)
- [**Readeing Progress Bar**](https://royal-elementor-addons.com/elementor-reading-progress-bar-widget/?ref=rea-wpo-pp-details-tab)
- [**Offcanvas Menu - sidebar menu**](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab)
- [**Twitter Feed**](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab)
- [**Instagram Feed**](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab)

**Woocommerce Widgets:**

- [**Advanced Woocommerce Product Grid**](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-woo-grid)
- [**Advanced Product Filters (Filter products by Color, brand, size etc)**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/?ref=rea-wpo-pp-details-tab)
- [**Woocommerce Product Wishlist & Compare Grid**](https://demosites.royal-elementor-addons.com/fashion-v2/shop-fashion-v2/?ref=rea-wpo-pp-details-tab)
- [**Woocommerce Product Wishlist Page**](https://demosites.royal-elementor-addons.com/fashion-v2/wishlist-fashion-v2/?ref=rea-wpo-pp-details-tab)
- [**Woocommerce Product Compare Page**](https://demosites.royal-elementor-addons.com/fashion-v2/compare-fashion-v2/?ref=rea-wpo-pp-details-tab)
- [**Live Ajax Search for Woocommerce**](https://demosites.royal-elementor-addons.com/elementor-ajax-search/?ref=rea-wpo-pp-details-tab)
- [**Product Carousel**](https://royal-elementor-addons.com/elementor-grid-widget-examples/product-carousel-examples/?ref=rea-wpo-pp-details-tab)
- [**Product Slider**](https://royal-elementor-addons.com/elementor-grid-widget-examples/product-slider-examples/?ref=rea-wpo-pp-details-tab#)
- [**Product Filters**](https://demosites.royal-elementor-addons.com/fashion-v1/shop-fashion-v1?ref=rea-wpo-pp-details-tab)
- [**Product Category Grid**](https://demosites.royal-elementor-addons.com/fashion-v1/?ref=rea-wpo-pp-details-tab#catgridprev)
- [**My Account**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/my-account-furniture-shop-v1/?ref=rea-wpo-pp-details-tab)
- [**Cart**](https://demosites.royal-elementor-addons.com/grocery-store-v1/cart-grocery-store-v1/?ref=rea-wpo-pp-details-tab)
- [**Checkout**](https://demosites.royal-elementor-addons.com/grocery-store-v1/checkout-grocery-store-v1/?ref=rea-wpo-pp-details-tab)
- [**Mini Cart**](https://demosites.royal-elementor-addons.com/grocery-store-v1/shop-grocery-store-v1/?ref=rea-wpo-pp-details-tab)
- [**Floating Mini Cart**](https://demosites.royal-elementor-addons.com/fashion-v1/shop-v2/?ref=rea-wpo-pp-details-tab)
- [**Breadcrumbs**](https://demosites.royal-elementor-addons.com/fashion-v1/product/simple-jumper-with-cap/?ref=rea-wpo-pp-details-tab)
- [**Add to Cart**](https://demosites.royal-elementor-addons.com/fashion-v1/product/simple-jumper-with-cap/?ref=rea-wpo-pp-details-tab)
- [**Product Price**](https://demosites.royal-elementor-addons.com/fashion-v1/product/simple-jumper-with-cap/?ref=rea-wpo-pp-details-tab)
- [**Product Navigation**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/product/delilah-fabric-cocktail-chair/?ref=rea-wpo-pp-details-tab)
- [**Product Media**](https://demosites.royal-elementor-addons.com/fashion-v1/product/urban-style-jacket-crop-top/?ref=rea-wpo-pp-details-tab)
- [**Product Tabs**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/product/delilah-fabric-cocktail-chair/?ref=rea-wpo-pp-details-tab)
- [**Product Meta**](https://demosites.royal-elementor-addons.com/grocery-store-v1/product/exotic-cantaloupe/?ref=rea-wpo-pp-details-tab)
- [**Product Rating**](https://demosites.royal-elementor-addons.com/grocery-store-v1/product/exotic-cantaloupe/?ref=rea-wpo-pp-details-tab)
- [**Product Sale Badge**](https://demosites.royal-elementor-addons.com/grocery-store-v1/product/exotic-cantaloupe/?ref=rea-wpo-pp-details-tab)
- [**Product Notice**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/product/delilah-fabric-cocktail-chair/?ref=rea-wpo-pp-details-tab)
- [**Product Excerpt**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/product/delilah-fabric-cocktail-chair/?ref=rea-wpo-pp-details-tab)
- [**Product Stock**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/product/delilah-fabric-cocktail-chair/?ref=rea-wpo-pp-details-tab)
- [**Product Additional Info**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/product/delilah-fabric-cocktail-chair/?ref=rea-wpo-pp-details-tab)


**Extensions and Other Features**

- [**Elementor Theme Builder & Woocommerce Builder**](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab#headerfooterbuilder) - Header Footer Builder, Post & Product Archive builder, Single Post & Product builder, Single Page, Search, category, tags, 404, author, data page template builder.
- [**Dynamic Website Builder**](https://www.youtube.com/watch?v=kE1zmi3fxh8) - Use Dynamic Tags to create Websites Driven by Dynamic Content. Create Custom Post Types and Custom Taxonomies. Style and customize Custom Fields, Custom Post Type & Custom Taxonomies Templates. Add Dynamic Product Data even for Woocommerce Archive Grid and Single Products Pages and much more. Supported Advanced Custom Fields: Text, Textarea, Number, Range, Email, URL, Password, Select, Checkbox, Radio Button, True / False, Gallery, Image, Repeater, File, Flexible Content, Clone, WYSIWYG Editor, oEmbed, Date Picker, Relationship, Taxonomy, Time Picker, Color Picker, Post Object, Accordion, Tab, Google Map. [View Dynamic Websites Prebuilt Demos](https://demosites.royal-elementor-addons.com/elementor-templates/#filter:category-dynamic)
- [**Advanced Filters for Elementor**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/) - Advanced Filters lets you filter any **Custom Post Types (CPT), Taxonomies and Metafields** in WordPress using Elementor. You can create filters like Price, Color, Brand, Size, Material, Rating or any other. Please watch this [Video Tutorial](https://www.youtube.com/watch?v=ejbvzt2BkJE) to learn more about it.
- [**Widget Builder - Create Custom Elementor Widgets Without Code**](https://royal-elementor-addons.com) - Build your own fully-functional Elementor widgets visually — no coding skills required. The Widget Builder lets you design custom widgets from scratch using an intuitive drag-and-drop control panel and a built-in code editor for those who want full creative control.  

	How it works:

	1. Add controls (text fields, color pickers, sliders, selects, media uploaders, and 20+ more) to your widget's Content, Style, and Advanced tabs — just like any native Elementor widget.
	2. Use simple template tags like {{title}} or {{image.url}} in the HTML editor to output control values dynamically.
	3. Add custom CSS and JavaScript to style and power your widget's behavior.
	4. Hit Preview to test your widget live inside Elementor, then Save — your widget is instantly available in the Elementor editor, ready to use on any page.

	Key highlights:

	- 20+ supported control types including text, number, color, slider, dimensions, select, media, gallery, icons, typography, background, border, box shadow, and more
	- Group controls for typography, background, borders, and shadows — matching native Elementor quality
	- Conditional logic with {{#if}} template tags to show/hide content based on control values
	- Built-in Monaco code editor (same editor used in VS Code) for HTML, CSS, and JavaScript
	- Link external CSS/JS libraries directly from the Includes panel
	- Live preview inside Elementor before saving
	- Custom icon and category assignment so your widgets feel native
	- Generated widgets are lightweight, performant, and stored as standard Elementor widget classes

	Whether you need a custom testimonial card, a pricing box with unique styling, a branded CTA section, or any element that doesn't exist as a pre-built widget — the Widget Builder lets you create it yourself in minutes, not hours.
- [**Mega Menu Builder**](https://royal-elementor-addons.com/elementor-mega-menu-widget/?ref=rea-wpo-pp-details-tab#popupbuilder?ref=rea-wpo-pp-details-tab#popupbuilder) - Build any type of WordPress mega menu with Menu Badges and Icons, use any elementor widgets in Mega menu content, supports Ajax loading of mega menu items for maximum page loading speed. Off-Canvas Mobile and Desktop Menus support.
- [**Advanced Sticky Menu - Create eye-catching Sticky Header Effects**](https://prnt.sc/pCVM2ayA_vVV) check demos (scroll to see menu effects): 
	[Demo 1 - Replace Header on Scroll, change it's background Color and make it Transparent, replace Logo ](https://demosites.royal-elementor-addons.com/construction-v3/?ref=rea-wpo-pp-details-tab)
	[Demo 2 - Shrink Logo, Shrink Header and Change its Color](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v1/?ref=rea-wpo-pp-details-tab) 
	[Demo 3 - Only show Header when Scrolling Up](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v2/?ref=rea-wpo-pp-details-tab)
	[Demo 4 - Replace Header and add Shadow, Replace Logo and Menu background Colors](https://demosites.royal-elementor-addons.com/personal-blog-v1/?ref=rea-wpo-pp-details-tab)
	[Demo 5 - Scale Logo, Scale Header and Change its background Color](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v1/?ref=rea-wpo-pp-details-tab)

- [**Popup Builder**](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab#popupbuilder) - (Offer Sales Banners, Subscriptions Banners, GDPR Cookie Consent & Compliance Notice, Cookie Notice, Age Verification), 20+ Premade Popup Templates included in popup library
- [**Parallax Scrolling**](https://royal-elementor-addons.com/elementor-parallax-background/?ref=rea-wpo-pp-details-tab) - Parallax effect extension
- [**Parallax Multi-Layer Effect**](https://royal-elementor-addons.com/elementor-parallax-background/?ref=rea-wpo-pp-details-tab#multiparallax) -  extension
- [**Particle Effect**](https://royal-elementor-addons.com/elementor-particle-effects/?ref=rea-wpo-pp-details-tab)
- White Label Branding (Change Plugin Name, Description, Developer / Agency, Website URL, Menu Label
and other custom branding related settings)
- Sticky Section (Can be used for creating Sticky Header / Menu)
- Custom CSS - apply custom css to any elementor section.

**Elementor Wocommerce Builder Templates Kits**

- [**Electronic Store**](https://demosites.royal-elementor-addons.com/estore-v1/?ref=rea-wpo-pp-details-tab)
- [**Auto Parts Store**](https://demosites.royal-elementor-addons.com/woo-auto-parts-v1/?ref=rea-wpo-pp-details-tab)
- [**Fashion 2**](https://demosites.royal-elementor-addons.com/fashion-v2/?ref=rea-wpo-pp-details-tab)
- [**Woo Shop 1**](https://demosites.royal-elementor-addons.com/wooshop-v1/?ref=rea-wpo-pp-details-tab)
- [**Woo Shop 2**](https://demosites.royal-elementor-addons.com/shop-wooshop-v2/?ref=rea-wpo-pp-details-tab)
- [**Fashion 1**](https://demosites.royal-elementor-addons.com/fashion-v1/?ref=rea-wpo-pp-details-tab)
- [**Grocery Store**](https://demosites.royal-elementor-addons.com/grocery-store-v1/?ref=rea-wpo-pp-details-tab)
- [**Furniture Store**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/?ref=rea-wpo-pp-details-tab)
- [**Food Delivery**](https://demosites.royal-elementor-addons.com/woo-food-v1/?ref=rea-wpo-pp-details-tab)
- [**Ecommerce**](https://demosites.royal-elementor-addons.com/ecommerce-v1/?ref=rea-wpo-pp-details-tab)
- [**+++++View All Demos +++++**](https://demosites.royal-elementor-addons.com/elementor-templates/?ref=rea-wpo-pp-details-tab)

**Elementor Theme Builder Templates Kits**

- [**Personal Blog v1**](https://demosites.royal-elementor-addons.com/personal-blog-v1/?ref=rea-wpo-pp-details-tab)
- [**Personal Blog v2**](https://demosites.royal-elementor-addons.com/personal-blog-v2/?ref=rea-wpo-pp-details-tab)
- [**Personal Blog v3**](https://demosites.royal-elementor-addons.com/personal-blog-v3/?ref=rea-wpo-pp-details-tab)
- [**Personal Blog v4**](https://demosites.royal-elementor-addons.com/personal-blog-v4/?ref=rea-wpo-pp-details-tab)
- [**Magazine Blog v1**](https://demosites.royal-elementor-addons.com/magazine-blog-v1/?ref=rea-wpo-pp-details-tab)
- [**Magazine Blog v2**](https://demosites.royal-elementor-addons.com/magazine-blog-v2/?ref=rea-wpo-pp-details-tab)
- [**Magazine Blog v3**](https://demosites.royal-elementor-addons.com/magazine-blog-v3/?ref=rea-wpo-pp-details-tab)
- [**Magazine Blog V4**](https://demosites.royal-elementor-addons.com/magazine-blog-v4/?ref=rea-wpo-pp-details-tab)
- [**Magazine Blog V6**](https://demosites.royal-elementor-addons.com/magazine-blog-v6/?ref=rea-wpo-pp-details-tab)
- [**Food Blog**](https://demosites.royal-elementor-addons.com/food-blog-v1/?ref=rea-wpo-pp-details-tab)
- [**Travel Blog**](https://demosites.royal-elementor-addons.com/travel-blog-v1/?ref=rea-wpo-pp-details-tab)
- [**+++++View All Demos +++++**](https://demosites.royal-elementor-addons.com/elementor-templates/?ref=rea-wpo-pp-details-tab)

**Elementor Templates Kits**

- [**Nature**](https://demosites.royal-elementor-addons.com/nature-v1/?ref=rea-wpo-pp-details-tab)
- [**Digital Agency**](https://demosites.royal-elementor-addons.com/digitalagency-v1/?ref=rea-wpo-pp-details-tab)
- [**Digital Agency**](https://demosites.royal-elementor-addons.com/digitalagency-v2/?ref=rea-wpo-pp-details-tab)
- [**Digital Agency**](https://demosites.royal-elementor-addons.com/digitalagency-v3/?ref=rea-wpo-pp-details-tab)
- [**It Technology 1**](https://demosites.royal-elementor-addons.com/ittech-v1/?ref=rea-wpo-pp-details-tab)
- [**Construction v1**](https://demosites.royal-elementor-addons.com/construction-v1/?ref=rea-wpo-pp-details-tab)
- [**Construction v2**](https://demosites.royal-elementor-addons.com/construction-v2/?ref=rea-wpo-pp-details-tab)
- [**Construction v3**](https://demosites.royal-elementor-addons.com/construction-v3/?ref=rea-wpo-pp-details-tab)
- [**Architecture**](https://demosites.royal-elementor-addons.com/architecture-v1/?ref=rea-wpo-pp-details-tab)
- [**It Technology 2**](https://demosites.royal-elementor-addons.com/ittech-v2/?ref=rea-wpo-pp-details-tab)
- [**Drone**](https://demosites.royal-elementor-addons.com/drone-v1/?ref=rea-wpo-pp-details-tab)
- [**Cybersecurity**](https://demosites.royal-elementor-addons.com/cybersecurity-v1/?ref=rea-wpo-pp-details-tab)
- [**Medical**](https://demosites.royal-elementor-addons.com/medical-v1/?ref=rea-wpo-pp-details-tab)
- [**Realestate**](https://demosites.royal-elementor-addons.com/realestate-v1/?ref=rea-wpo-pp-details-tab)
- [**Cryptocurrency**](https://demosites.royal-elementor-addons.com/cryptocurrency-v1/?ref=rea-wpo-pp-details-tab)
- [**Skincare**](https://demosites.royal-elementor-addons.com/skincare-v1/?ref=rea-wpo-pp-details-tab)
- [**Food Delivery**](https://demosites.royal-elementor-addons.com/fooddelivery-v1/?ref=rea-wpo-pp-details-tab)
- [**Wedding**](https://demosites.royal-elementor-addons.com/wedding-v1/?ref=rea-wpo-pp-details-tab)
- [**Restaurant**](https://demosites.royal-elementor-addons.com/restaurant-v1/?ref=rea-wpo-pp-details-tab)
- [**Portfolio**](https://demosites.royal-elementor-addons.com/portfolio-v1/?ref=rea-wpo-pp-details-tab)
- [**Developer Portfolio**](https://demosites.royal-elementor-addons.com/developer-portfolio-v1/?ref=rea-wpo-pp-details-tab)
- [**Designer Bio**](https://demosites.royal-elementor-addons.com/designer-bio-v1/?ref=rea-wpo-pp-details-tab)
- [**Pizza Restaurant**](https://demosites.royal-elementor-addons.com/pizza-v1/?ref=rea-wpo-pp-details-tab)
- [**Wine Bar**](https://demosites.royal-elementor-addons.com/winebar-v1/?ref=rea-wpo-pp-details-tab)
- [**Photographer Portfolio Dark**](https://demosites.royal-elementor-addons.com/photographer-v1/?ref=rea-wpo-pp-details-tab)
- [**Photographer Portfolio Light**](https://demosites.royal-elementor-addons.com/photographer-v2/?ref=rea-wpo-pp-details-tab)
- [**Lawyer Light version**](https://demosites.royal-elementor-addons.com/lawyer-v1/?ref=rea-wpo-pp-details-tab)
- [**Travel Blogger & Influencer Light version**](https://demosites.royal-elementor-addons.com/travel-v1/?ref=rea-wpo-pp-details-tab)
- [**NFT**](https://demosites.royal-elementor-addons.com/nft-portfolio-v1/?ref=rea-wpo-pp-details-tab)
- [**Car Wash**](https://demosites.royal-elementor-addons.com/carwash-v1/?ref=rea-wpo-pp-details-tab)
- [**Pet Care**](https://demosites.royal-elementor-addons.com/pet-care-v1/?ref=rea-wpo-pp-details-tab)
- [**Pet Shop**](https://demosites.royal-elementor-addons.com/pet-shop-v1/?ref=rea-wpo-pp-details-tab)
- [**Digital Marketing Agency**](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v1/?ref=rea-wpo-pp-details-tab)
- [**One Page Digital Marketing Agency v1**](https://demosites.royal-elementor-addons.com/one-page-v1/?ref=rea-wpo-pp-details-tab)
- [**One Page Digital Marketing Agency v2**](https://demosites.royal-elementor-addons.com/one-page-v2/?ref=rea-wpo-pp-details-tab)
- [**Travel Agency**](https://demosites.royal-elementor-addons.com/travel-agency-v1/?ref=rea-wpo-pp-details-tab)
- [**Architecture & Interior**](https://demosites.royal-elementor-addons.com/architecture-v2/?ref=rea-wpo-pp-details-tab)
- [**Fytness & Gym**](https://demosites.royal-elementor-addons.com/fitness-gym-v1/?ref=rea-wpo-pp-details-tab)
- [**Business Consulting**](https://demosites.royal-elementor-addons.com/business-consulting-v1/?ref=rea-wpo-pp-details-tab)
- [**Car Repair**](https://demosites.royal-elementor-addons.com/car-repair-v1/?ref=rea-wpo-pp-details-tab)
- [**Amazon Product Landing Page**](https://demosites.royal-elementor-addons.com/amazon-landing-page-v1/?ref=rea-wpo-pp-details-tab)
- [**Business Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-business-v1/?ref=rea-wpo-pp-details-tab)
- [**Mobile App Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-mobileapp-v1/?ref=rea-wpo-pp-details-tab)
- [**Investment Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-investment-platform-v1/?ref=rea-wpo-pp-details-tab)
- [**Digital Product Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-digital-product-v1/?ref=rea-wpo-pp-details-tab)
- [**Saas Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-saas-v1/?ref=rea-wpo-pp-details-tab)
- [**Startup Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-startup-v1/?ref=rea-wpo-pp-details-tab)
- [**Ebook Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-ebook-v1/?ref=rea-wpo-pp-details-tab)
- [**Home Care**](https://demosites.royal-elementor-addons.com/home-care-v1/?ref=rea-wpo-pp-details-tab)
- [**Fintech**](https://demosites.royal-elementor-addons.com/fintech-v1/?ref=rea-wpo-pp-details-tab)
- [**Portfolio v2**](https://demosites.royal-elementor-addons.com/portfolio-v2/?ref=rea-wpo-pp-details-tab)
- [**Hotel v1**](https://demosites.royal-elementor-addons.com/hotel-v1/?ref=rea-wpo-pp-details-tab)
- [**Nature - Travel v2**](https://demosites.royal-elementor-addons.com/nature-v2/?ref=rea-wpo-pp-details-tab)
- [**Yoga**](https://demosites.royal-elementor-addons.com/yoga-v1/?ref=rea-wpo-pp-details-tab)
- [**Digital Seo Marketing Agency v1**](https://demosites.royal-elementor-addons.com/digital-seo-marketing-agency-v1/?ref=rea-wpo-pp-details-tab)
- [**Digital Seo Marketing Agency v2**](https://demosites.royal-elementor-addons.com/digital-seo-marketing-agency-v2/?ref=rea-wpo-pp-details-tab)
- [**Real Estate v2**](https://demosites.royal-elementor-addons.com/realestate-v2/?ref=rea-wpo-pp-details-tab)
- [**Real Estate Agency v3**](https://demosites.royal-elementor-addons.com/realestate-v3/?ref=rea-wpo-pp-details-tab)
- [**Job Listing Website**](https://demosites.royal-elementor-addons.com/job-listing-v1/?ref=rea-wpo-pp-details-tab)
- [**Barber Shop Kit**](https://demosites.royal-elementor-addons.com/barbershop-v1/?ref=rea-wpo-pp-details-tab)
- [**Dance Studio Kit**](https://demosites.royal-elementor-addons.com/dance-studio-v1/?ref=rea-wpo-pp-details-tab)
- [**Magazine Blog V4**](https://demosites.royal-elementor-addons.com/magazine-blog-v4/?ref=rea-wpo-pp-details-tab)
- [**Solar Energy Kit**](https://demosites.royal-elementor-addons.com/solar-energy-v1/?ref=rea-wpo-pp-details-tab)
- [**Digital Marketing Agency v3**](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v3/?ref=rea-wpo-pp-details-tab)
- [**Digital Marketing Agency v2**](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v2/?ref=rea-wpo-pp-details-tab)
- [**Digital Agency Dark**](https://demosites.royal-elementor-addons.com/digital-agency-dark-v1/?ref=rea-wpo-pp-details-tab)
- [**Charity**](https://demosites.royal-elementor-addons.com/charity-v1/?ref=rea-wpo-pp-details-tab)
- [**Coming Soon Kit v1**](https://demosites.royal-elementor-addons.com/coming-soon-pack-v1/?ref=rea-wpo-pp-details-tab)
- [**Music Band v1**](https://demosites.royal-elementor-addons.com/music-band-v1/?ref=rea-wpo-pp-details-tab)
- [**Dental v1**](https://demosites.royal-elementor-addons.com/dental-v1/?ref=rea-wpo-pp-details-tab)
- [**+++++View All Demos +++++**](https://demosites.royal-elementor-addons.com/elementor-templates/?ref=rea-wpo-pp-details-tab)

**How to Import Template Kit:**

Navigate to plugin **Menu > Templates Kit > Select Kit you want to import > Click on the import Template Kit** button.
Demo Data will be installed from [Our Website](https://royal-elementor-addons.com/).
What's imported: Posts, pages, images in the media library, menu items, some basic settings like which page will be set as homepage, premade headers, and premade footers, popups if demo includes it.
If you already have posts, pages, or any other data in your WordPress none of them will be deleted.

**Widgets short Description:**

== 1. Elementor Post Grid ==

[Post Grid - Post Slider - Post Carousel](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-portfolio-grid) - A free Elementor Post grid widget. This widget could be used as a recent posts slider, post carousel, FitRows grid, masonry grid (Pro), portfolio grid, list style grid, filtrable grid if you will enable isotope filters, media grid for video project showcase and more. Simply the best solution for WordPress blog posts or custom post types. Comes with the following options: multicolumns, numbered pagination, random post display option, load more button, infinite scroll (Pro), likes (Pro), sharing (Pro), custom fields (Pro), lightbox, linkable filters (deep linking), custom icons for filters, grid filters (live filters with isotope) and much more.

== 2. Elementor Woocommerce Grid ==

[WooCommerce Product Grid - Product Slider - Product Carousel](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-woo-grid) - A free WooCommerce Grid Widget. Could be used as  product carousel, product slider, product list, product category grid, category carousel, category slider, filtrable grid to display wooCommerce products and much more. This elementor addon comes with the following options: multicolumn, numbered pagination, load more button, infinite scroll (Pro), product likes (Pro), product sharing (Pro), custom fields (Pro), lightbox with the gallery, linkable filters (deep linking), custom icons for filters, live grid filters (with isotope filters), sorting and much more.

== 3. Image Grid ==

[Image Grid - Image Slider - Image Carousel](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-gallery-grid) - A free Image Grid Widget. Could be used as an image gallery, logo grid, image slider, image carousel, and much more. Addon comes with the following options: multicolumn grids, numbered pagination, load more button, infinite scroll (Pro), likes (Pro), sharing (Pro), custom fields (Pro), lightbox, linkable filters (deep linking), custom icons for the filters, FitRows grid with a isotope filters, masonry grid and much more.

[Magazine Grid - Slider](https://royal-elementor-addons.com/elementor-grid-widget-examples/?ref=rea-wpo-pp-details-tab#filter:category-magazine-grid) - A free Magazine Grid Widget. This widget is the #1 Magazine Grid builder widget on the repository. Could be used as magazine layout, newspaper layout, news grid, news slider(PRO).

== 5. Advanced Slider ==

[Advanced Slider - Carousel](https://royal-elementor-addons.com/elementor-advanced-slider-widget/?ref=rea-wpo-pp-details-tab) - A free Image Slider Widget. Could be used as image slider, logo carousel, content slider, template slider (Pro). Creat unique looking hero section with this slider. It is fully responsive and has full width and full screen options. Also Pro version comes with Ken Burns effect & animated content.

== 6. Testimonial Slider ==

[Testimonial Slider](https://royal-elementor-addons.com/elementor-testimonials-slider-widget/?ref=rea-wpo-pp-details-tab) - A free Testimonial Slider Widget. This widget will showcase your customers reviews on your WordPress website. The widget offers following options: customers reviews slider, testimonials ratings (stars), company logo option, clients/customer image, texts with vintage quotes.

== 7. Elementor Menu widget ==

[Nav Menu](https://royal-elementor-addons.com/elementor-menu-widget/?ref=rea-wpo-pp-details-tab) - A free Nav Menu Widget. This widget will make your WordPress Menu trully unique by customizing its look and feel without using code. Addon offers following options:  mobile menu customization, drop down menu setup, hamburger menu, menu hover effects and hover animations. Also Pro version offers vertical menu and sticky header. Most advanced & customizable responsive menu.

== 8. Onepage Navigation ==

[Onepage Navigation](https://royal-elementor-addons.com/elementor-one-page-navigation-widget/?ref=rea-wpo-pp-details-tab) - A free Onepage Navigation Widget. This widget allows you to create an amazing onepage scroll experiance WordPress website with just a few clicks. Can be used to create floating menu, sticky navigation menu, side menu with icons to scroll to any section.

== 9. Pricing Table ==

[Pricing Table](https://royal-elementor-addons.com/elementor-pricing-table-widget/?ref=rea-wpo-pp-details-tab) - A free Pricing Table Widget. This Pricing Comparison Table widget helps you to create an effective price comparison table with unique styling, which allows you to display not just the cost, but also the features you offer. A widget could be used as a regular pricing table & as a pricing table with a toggle button to switch from Monthly/Yearly plans. Pro version offers different tooltip options for each pricing table feature, also it's possible to have more than 2 pricing plans switcher, like Monthly/Yearly/Lifetime (You can check the demo on the widget preview page).

== 10. Content Toggle ==

[Content Toggle](https://royal-elementor-addons.com/elementor-content-toggle-widget/?ref=rea-wpo-pp-details-tab) - A free Content Toggle Widget. You can load Elementor Templates or simply insert images and text to style it the way you want. A widget could be used as a pricing switcher as well, for example, to switch between Monthly/Yearly/Lifetime pricing plans. Pro version offers more than 2 toggle options - Check out the widget demo page to see all its possibilities.

== 11. Countdown Timer ==

[Countdown Timer](https://royal-elementor-addons.com/elementor-countdown-widget/?ref=rea-wpo-pp-details-tab) - This widget allows you to display a timer that counts down to a specific time or date. A widget could be used as a black Friday sale countdown timer, to create urgency for users for your event, sales, or opt-in forms. You can set various actions after the timer expires: hide the timer, display a message, redirect or load the template. The Pro version offers an Evergreen timer (checkout widget demo page), recurring countdown timer, and restart timer options.

== 12. Progress Bar ==

[Progress Bar](https://royal-elementor-addons.com/elementor-progress-bar-widget/?ref=rea-wpo-pp-details-tab) - This Skill Bar widget offers unique ways to style various types of stats in percentages or numbers, can be used for classic animated progress bars, circle progress bars, or vertical progress bars (Pro).

== 13. Advanced Tabs ==

[Tabs](https://royal-elementor-addons.com/elementor-tabs-widget/?ref=rea-wpo-pp-details-tab) - This Advanced Tab widget lets you display key information in an interactive manner, that attracts visitors and also saves lots of space on your WordPress webpage. The widget offers horizontal tabs, vertical tabs, tab loading animation effects, and more. Trigger tab via mouse hover or click both options are available. Also, you can have nested tabs via the elementor templates loader which means you can use any elementor addons inside tab content.

== 14. Advanced Text ==

[Advanced Text - Fancy Text](https://royal-elementor-addons.com/elementor-advanced-text-widget/?ref=rea-wpo-pp-details-tab) - This Text animation widget lets you highlight any text with different colors, animation, and typing effects to draw your visitor's attention instantly. Available effects: typewriter effect, fancy text effect, animated text effect, highlighted text effect, text-shadow effect, text over image effect, text and image mask effect, 3d text effect, text slider, gradient text, the background image on text, text glitch effect, text long colored shadow effect, word animation effect, text skew effect, text flip vertical and horizontal effect, slide, clip, zoom, scale, circle line, underline zigzag line, curly line, cross x line, line through and others. Pro Version offers extra effects and functionalities.

== 15. Flip Box ==

[Flip Box](https://royal-elementor-addons.com/elementor-flip-box-widget/?ref=rea-wpo-pp-details-tab) - A free Flip Box Widget. This widget with hover box animation and call-to-action buttons will highlight your content in a great way and allows you to create stunning promo boxes and ads with CTA button functionality. The widget offers more flipping effects in the pro version and some extra functionality as well.

== 16. Promo Box ==

[Promo Box](https://royal-elementor-addons.com/elementor-promo-box-widget/?ref=rea-wpo-pp-details-tab) - With this widget, you can create: a clickable image with varios effects like: a clickable image with image hover effects, option to add text over image, display call to action button over image, and many other options. Create a stunning sale or discount banners with CTA buttons and badges with this addon. The Pro Version offers extra effects and functionalities.

== 17. Before After Slider ==

[Before After Slider - Image comparison Slider](https://royal-elementor-addons.com/elementor-before-after-widget/?ref=rea-wpo-pp-details-tab) - A free Image comparison slider. This addon can compare two pictures with draggable or mouse hover options in horizontal and vertical(Pro) layouts.

== 18. Image Hotspot ==

[Image Hotspots](https://royal-elementor-addons.com/elementor-image-hotspot-widget/?ref=rea-wpo-pp-details-tab) - A free Image Map Widget to build image hotspot maps, allows you to create hot spot image with 2x points on it. Add tooltips to icons to make it stunning and informative. The PRO versions offer unlimited hotspot points.

== 19. Forms Styler ==

[Forms](https://royal-elementor-addons.com/elementor-forms-widget/?ref=rea-wpo-pp-details-tab) - This Form widget comes with the following options: contact form 7 styler, Gravity forms styler, Ninja Forms styler, and WPforms styler.

== 20. MailChimp Subscribe ==

[MailChimp](https://royal-elementor-addons.com/elementor-mailchimp-subscription-widget/?ref=rea-wpo-pp-details-tab) - This Newsletter addon helps you to collect emails from your website visitors by creating stunning email opt-in forms. Our Mailchimp Form is the best free Mailchimp integration tool for your WordPress website. Add a stunning signup form to your page and collect your subscriber's emails to create an effective email campaign. The PRO version offers some extended functionality for this widget.

== 21. Content Ticker ==

[Content Ticker](https://royal-elementor-addons.com/elementor-content-ticker-widget/?ref=rea-wpo-pp-details-tab) - This News Ticker widget helps you showcase trending posts with unique animation effects, and will give your website a stunning look that attracts your audience's attention. Can be used to display: recent posts, hot / trending posts with a blinking effect. Custom post types supported only in the PRO version.

== 22. Button Widget ==

[Button](https://royal-elementor-addons.com/elementor-button-widget/?ref=rea-wpo-pp-details-tab) - A free Button Widget with button animations. This Widget helps you create conversion-friendly call to action sections and comes with advanced button features like 2d animations, button animation, background animations, text animations, custom icons, gradient effects, rounded corners, background images, hover shadow, and many more.

== 23. Dual Button Widget ==

[Dual Button](https://royal-elementor-addons.com/elementor-button-widget/?ref=rea-wpo-pp-details-tab#dualbuttonsection) - This Dual Button Widget will place two buttons side by side that help you create a conversion-friendly call to action sections. Custom Icon can be placed in the middle of the buttons.

== 24. Team Member Widget ==

[Team Member](https://royal-elementor-addons.com/elementor-team-member-widget/?ref=rea-wpo-pp-details-tab) - A free Team Member Widget aka profile widget. This Widget is the best & fastest way to build a team grid to introduce your team members and add credibility to your WordPress website. Addon comes with image, name, surname, job, position, social links, button, and biographic info (bio) fields. It is a great way to add company members, staff, workers, employees, or people with rich member profiles to your page. With the Pro version, you can create a team member slider or team carousel.

== 25. Google Maps Widget ==

[Google Maps](https://royal-elementor-addons.com/elementor-google-maps-widget/?ref=rea-wpo-pp-details-tab) - This widget gives you full control over the configuration, with the multiple locations option you can set multiple addresses. Map Comes with a custom marker and tooltip options. Choose from different google map types: roadmap, satellite, hybrid or terrain. Show/hide controls like street view and more. Also, our addon allows you to change a color scheme with a custom skin option.

== 26. Price List Widget ==

[Price List](https://royal-elementor-addons.com/elementor-price-list-widget/?ref=rea-wpo-pp-details-tab) - This Price table widget lets you create an amazing Restaurant Menu or price lists for your products or business very easily. It comes with lots of different styles so you can get a unique and top-notch design to make your price list attractive.

== 27. Business Hours Widget ==

[Business Hours](https://royal-elementor-addons.com/elementor-business-hours-widget/?ref=rea-wpo-pp-details-tab) - This Widget offers the following options: opening times table and closing hours table. Rich controls allow you to customize this widget in many ways.

== 28. Sharing Buttons ==

[Sharing Buttons](https://royal-elementor-addons.com/elementor-social-sharing-buttons-widget/?ref=rea-wpo-pp-details-tab) - A free Share Buttons Widget. This widget lets you share your pages and blog posts on any popular social media websites. Available platforms: Facebook, Twitter, Linkedin, Pinterest, Reddit, Tumblr, Digg, Xing, Stumble upon, Vkontakte, Odnoklassniki, Pocket, Skype, Whatsapp, Telegram, Delicious, Email, Print, etc...The Pro version offers much more customization options.

== 29. Search Form ==

[Search Form](https://royal-elementor-addons.com/elementor-search-widget/?ref=rea-wpo-pp-details-tab) - This Search Form could be used as a custom post type search form, product search form, woocommerce search form. Multiple styling options let you customize your WordPress search bar in a unique way. In the latest version, Ajax search was added with advanced controlls for maximum customiztion.

== 30. Site Logo ==

[Site Logo](https://royal-elementor-addons.com/) - This widget comes with the following features: retina logo support, custom mobile logo, custom logo URL and tagline customization options.

== 31. Back to Top Button ==

[Back to top Button](https://royal-elementor-addons.com/elementor-back-to-top-widget/?ref=rea-wpo-pp-details-tab) - A free Back to top button aka scroll to top button. Can be displayed on page bottom or anywhere in the page content as well.

== 32. Phone Call Button ==

[Phone Call Button](https://royal-elementor-addons.com/elementor-phone-call-widget/?ref=rea-wpo-pp-details-tab) - A free Phone Call Button. Can be displayed on page bottom or anywhere in the page content.

== 33. Lottie Animation ==

[Lottie Animation](https://royal-elementor-addons.com/elementor-lottie-animation-widget/?ref=rea-wpo-pp-details-tab) Our Lottie animation widget gives you the ability to easily add Lottie Animations to your pages. Comes with features like reverse Lottie animation, autoplay, loop, different render types of Lottie animation like SVG or Canvas, rotate or change animation size, manipulate with animation speed, trigger animation on hover, on viewport or on scroll. Ability to Add a custom link on the Lottie animation and lots of other features. Use CSS Filters Effects to completely change Lottie's animation visual. Ability to load Lottie animation from multiple sources - Load with Custom link or Media library.

== 34. Timeline Widget ==

[Timeline Widget](https://royal-elementor-addons.com/elementor-timeline-widget/?ref=rea-wpo-pp-details-tab) - Create your timeline chart using our timeline grid widget. Comes with horizontal (timeline slider), vertical (one-sided) & zigzag styles. Advanced styling for timeline items, content, backgrounds, etc. Can be used to create a history timeline, blog timeline, event timeline, story timeline, company timeline, post timeline, timeline slider & video timeline. The widget Layout is mobile and tablet ready. You can display your WordPress blog posts as timeline items or create your own custom timeline items.

== 35. Elementor Mega Menu Widget ==

[Mega Menu Widget](https://royal-elementor-addons.com/elementor-mega-menu-widget/?ref=rea-wpo-pp-details-tab) - A free Mega Menu Widget. Use any elementor addons to display inside megamnu. We have developed a Page list widget, especially for megamenu which helps quickly display all pages in megamenu items. Also, Custom page badges can be set with megamenu page list widget. Our widget supports Horizontal and Vertical megamenu layouts. Some of the PRO features: Load Megamenu SubMenu Items with Ajax for maximum page speed scores, Add Icons and Badges to mega menu items, Set Submenu width to Automatically Fit to Section width where mega menu widget is placed, Display Mobile Menu sub-items as Mega Menu Item or WordPress Default Sub Item, Mobile Menu Off-Canvas Layout, Megamenu SubMenu Width option, Advanced Link Hover Effects: Slide, Grow, Drop, Mega menu SubMenu Entrance Advanced Effects, Mobile Menu Button Custom Text option. 

== 36. Elementor Instagram Feed Widget ==

[Instagram Feed Widget](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab) - The Instagram Feed Widget allows you to showcase your Instagram posts in various ways directly from your account. You have the flexibility to personalize the feed style, color, content, and more. The widget provides a range of styles to choose from, including: a photo-only feed, list style, photo list with hover, posts with a card layout, overlay feed, carousel layout, gallery masonry layout, and a feed with a profile link.

== 37. Twitter Feed Widget ==

[Twitter Feed Widget](https://royal-elementor-addons.com/?ref=rea-wpo-pp-details-tab) - Showcase images, profiles, and tweets seamlessly on your website with the Twitter Feed Widget. You have the ability to tailor the styles, layout, cover photo, header, dashboard, and more with the Twitter Feed Addon. The addon provides multiple styles to choose from, including cover photo style, masonry style, masonry style with multiple columns, grid style with a cover photo, carousel and slider style feed, and the ability to display a follow button.

== Checkout other widgets on our demo page ==


Widgets and other features will be added with each major update based on popular demand. We are relly trying to make this plugin on of the best in the repository.


== Installation ==

Note : This plugin works with Elementor. Make sure you have Elementor installed.

1. Install the plugin through the WordPress plugins screen directly, or Upload the plugin files to the `/wp-content/plugins/royal-elementor-addons` directory,
2. Activate the plugin through the 'Plugins' screen in WordPress
3. All Settings will be found in Admin sidebar menu -> Royal Addons
4. Also you can see all Widgets under the category “Royal Elementor Addons” inside Elementor editor in your element/widget list.

If you have any questions please check out <a href="https://wordpress.org/plugins/royal-elementor-addons/#faq" rel="nofollow">FAQ</a> page or contact us via this  <a href="https://royal-elementor-addons.com/contact/?ref=rea-wpo-pp-install-tab" rel="nofollow">Contact form</a>


== Frequently Asked Questions ==

= We have a query not addressed here, how can we contact you? =

Feel free to contact use anytime via this  <a href="https://royal-elementor-addons.com/contactus/?ref=rea-wpo-pp-details-tab-faq" rel="nofollow" target="_blank">Contact form</a>

= Can I use the plugin without Page Builder Plugin? =

No. You cannot use without Elementor since it's an addon for Elementor.

= Editor fails to load or not working? =
It's due to your server PHP settings. Increase your server PHP memory limit from the wp-config.php file or php.ini file.  If you don't have an idea about it. Please contact your hosting provider and ask to increase this parameters
* PHP memory_limit = 512M
* max_execution_time = 300

= Does it work with any theme? =

YES! It will work with any theme where Elementor works.

= Will your plugin affect the performance of my site? =

We run tests to ensure the speed of the site is not affected when you activate our Elementor addons. We provide a way for you to deactivate those Elementor modules that you do not require for your site to avoid loading them unnecessarily on the pages built with Elementor page builder.

= What if I update to Premium version? =

Your existing Elementor elements & content will work with premium version. So you won't lose your developed contents or any elementor elements.

= Can I use Royal Addons on a wordpress.com site? =

Since the plugin is hosted on wordpress.org, it is available on wordpress.com as well. However, you may need to opt for a business plan to install/activate third-party plugins on wordpress.com.

= Does it work with Pro version of Page Builder? =

Yes, undoubtedly our addon works with Elementor Pro Version.

= What Are the Recommended PHP Settings =

Minimum php version 5.6
memory_limit 256M or more
post_max_size 64M

= How can I report security bugs? =

You can report security bugs through the Patchstack Vulnerability Disclosure Program. The Patchstack team help validate, triage and handle any security vulnerabilities. [Report a security vulnerability.](https://patchstack.com/database/vdp/royal-elementor-addons)

== Changelog ===
= Royal Elementor Addons v1.7.1051 - 2026-03-09 =
* ADDED: A Widget Builder that helps you easily create custom widgets for Elementor

= Royal Elementor Addons v1.7.1050 - 2026-03-05 =
* Fixed: Some Bugs.
* ADDED: Elementor Template Kit: Business Landing Page V4 - [**Landing Page Business V4**](https://demosites.royal-elementor-addons.com/landing-page-business-v4/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Template Kit: Cosmetics V4 - [**Cosmetics V1**](https://demosites.royal-elementor-addons.com/cosmetic-v1/?ref=rea-wpo-pp-details-tab).


= Royal Elementor Addons v1.7.1049 - 2026-02-12 =
* ADDED: Backup Reminder when editing Theme Builder Elementor Templates.

= Royal Elementor Addons v1.7.1048 - 2026-02-10 =
* ADDED: Elementor Logistic Template Kit - [**Logistic / Transportation**](https://demosites.royal-elementor-addons.com/logistic-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1047 - 2026-02-03 =
* ADDED: Elementor AI Support BOT Template Kit - [**AI Support BOT**](https://demosites.royal-elementor-addons.com/ai-support-bot-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1046 - 2026-01-23 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1045 - 2026-01-05 =
* ADDED: Support for Royal Backup and Reset Plugin - [**Royal Backup and Reset Plugin**](https://wordpress.org/plugins/royal-backup-reset/#description).
* FIXED: Advanced Filters minor issues with some Template Kits - See it in Action [**Advanced Filters Preview**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1044 - 2026-01-04 =
* ADDED: Elementor AI Image Generation Template Kit - [**AI Image Generation**](https://demosites.royal-elementor-addons.com/ai-image-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor AI SAAS Platform Template Kit - [**AI SAAS Platform**](https://demosites.royal-elementor-addons.com/ai-saas-v1//?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Fast Food Restaurant Template Kit - [**Fast Food Restaurant**](https://demosites.royal-elementor-addons.com/fast-food-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Advanced Filters minor issues with some Template Kits - See it in Action [**Advanced Filters Preview**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1043 - 2025-12-29 =
* FIXED: Advanced Filters minor issues with some Template Kits - See it in Action [**Advanced Filters Preview**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1042 - 2025-12-24 =
* ADDED: Elementor Fashion (Shop) V5 Template Kit - [**Fashion**](https://demosites.royal-elementor-addons.com/fashion-v5/?ref=rea-wpo-pp-details-tab).
* FIXED: Advanced Filters minor issues with some Template Kits - See it in Action [**Advanced Filters Preview**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1041 - 2025-11-25 =
* FIXED: Advanced Filters minor issues with some Template Kits - See it in Action [**Advanced Filters Preview**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1040 - 2025-11-18 =
* FIXED: Advanced Filters minor issues with some Template Kits - See it in Action [**Advanced Filters Preview**](https://demosites.royal-elementor-addons.com/woo-advanced-filters-preview/preview-links/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1039 - 2025-11-13 =
* NEW: First Kit Where we have implemented Advanced Filters (Filter any type of CPT, Taxonomy and Metafields) - See it in Action [**Advanced Filters Preview 1**](https://demosites.royal-elementor-addons.com/fashion-v2/shop-fashion-v2/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1038 - 2025-11-11 =
* FIXED: Minor Bugs
* ADDED: Advanced Filters widget to Filter any type of CPT, Taxonomy and Metafields.

= Royal Elementor Addons v1.7.1037 - 2025-11-7 =
* Fixed: Mobile menu click on desktop in Mega Menu.
* Fixed: Minor vulnerability in Form Builder file upload action.
* Fixed: Minor bugs in Grid and Mega Menu modules.
* Fixed: Number of columns error in Advanced Slider widget.
* Fixed: Minor sanitization-related vulnerability in Form Builder.
* Added: Google Maps widget option to work without API Key.
* Fixed: Randomize option duplicating posts in Magazine Grid.
* Fixed: Lightbox popup minor bug in Media Grid.
* Added: Title HTML tag option in Posts Timeline.
* Added: Inline/Separate display option for Checkout buttons in Cart Page widget.
* Fixed: Safari rendering bugs in Add to Cart widget.

= Royal Elementor Addons v1.7.1036 - 2025-10-26 =
* ADDED: Wooshop V2 - Elementor Template Kit [**Wooshop V2**](https://demosites.royal-elementor-addons.com/wooshop-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Real Estate Consultant - Elementor Template Kit [**Real Estate Consultant**](https://demosites.royal-elementor-addons.com/real-estate-consultant-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1035 - 2025-10-8 =
* ADDED: Life Coach V1 - Elementor Template Kit - [**Life Coach V1**](https://demosites.royal-elementor-addons.com/life-coaching-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Day Care Services V1 - Elementor Template Kit - [**Day Care Services V1**](https://demosites.royal-elementor-addons.com/day-care-service-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1034 - 2025-9-19 =
* ADDED: Healthy Coaching V2 - Elementor Template Kit - [**Healthy Coaching V2**](https://demosites.royal-elementor-addons.com/healthy-coaching-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1033 - 2025-9-16 =
* FIXED: Minor Bugs
* ADDED: Business Coaching V2 - Elementor Template Kit - [**Business Coaching V2**](https://demosites.royal-elementor-addons.com/business-coaching-v2/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1032 - 2025-9-5 =
* FIXED: Minor Bugs
* ADDED: Lawyer V2 - Elementor Templates Kit - [**Lawyer V2**](https://demosites.royal-elementor-addons.com/lawyer-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Online Course V2 - Elementor Templates Kit - [**Online Course V2**](https://demosites.royal-elementor-addons.com/online-course-v2/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1031 - 2025-8-15 =
* FIXED: Minor Changes

= Royal Elementor Addons v1.7.1030 - 2025-8-06 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1029 - 2025-8-03 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1028 - 2025-7-26 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1027 - 2025-7-04 =
* ADDED: Car Detailing V1 - Elementor Templates Kit - [**Car Detailing V1**](https://demosites.royal-elementor-addons.com/car-detailing-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1026 - 2025-6-18 =
* ADDED: Digital Marketing Agency V4 - Elementor Templates Kit - [**Digital Marketing Agency V4**](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v4/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1025 - 2025-6-10 =
* FIXED: Minor Bugs
* ADDED: Taxonomy Condition for Single Templates of Theme Builder (by placing taxonomy-name/term-id in place of 'all')
* ADDED: Language option for google maps in dashboard settings

= Royal Elementor Addons v1.7.1024 - 2025-6-5 =
* ADDED: Business Landing Page V3 - Elementor Templates Kit - [**Landing Page Business V3**](https://demosites.royal-elementor-addons.com/landing-page-business-v3/?ref=rea-wpo-pp-details-tab).
* ADDED: Medical V2 - Elementor Templates Kit - [**Medical V2**](https://demosites.royal-elementor-addons.com/medical-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Yoga V2 - Elementor Templates Kit - [**Yoga V2**](https://demosites.royal-elementor-addons.com/yoga-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Nutritionist V1 - Elementor Templates Kit - [**Nutritionist V1**](https://demosites.royal-elementor-addons.com/nutritionist-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1023 - 2025-6-2 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1022 - 2025-5-28 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1021 - 2025-5-27 =
* FIXED: Minor Bugs
* FIXED: Freemius Security Related Issues

= Royal Elementor Addons v1.7.1020 - 2025-5-21 =
* ADDED: Auto Parts Store V2 Elementor Templates Kit - [**Auto Parts Store V2**](https://demosites.royal-elementor-addons.com/woo-auto-parts-v2/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1019 - 2025-5-15 =
* ADDED: News Magazine Blog V8 - Elementor Template Kit - [**Magazine V8**](https://demosites.royal-elementor-addons.com/magazine-blog-v8/?ref=rea-wpo-pp-details-tab).
* ADDED: News Magazine Blog V9 - Elementor Template Kit - [**Magazine V9**](https://demosites.royal-elementor-addons.com/magazine-blog-v9/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1018 - 2025-5-01 =
* FIXED: Minor Tweaks
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1017 - 2025-4-20 =
* FIXED: Minor Tweaks

= Royal Elementor Addons v1.7.1016 - 2025-4-02 =
* ADDED: Travel Agency v3 - Elementor Template Kit - [**Travel Agency V3**](https://demosites.royal-elementor-addons.com/travel-agency-v3/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1014 - 2025-3-31 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1013 - 2025-3-28 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1012 - 2025-3-14 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1010 - 2025-2-20 =
* ADDED: Business Coaching V1 - Elementor Template Kit - [**Business Coaching V1**](https://demosites.royal-elementor-addons.com/business-coaching-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1009 - 2025-2-12 =
* ADDED: Electronic Store V2 - Elementor Template Kit - [**Electronic Store V2**](https://demosites.royal-elementor-addons.com/estore-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Personal Coach - Elementor Template Kit - [**Personal Coach**](https://demosites.royal-elementor-addons.com/personal-coach-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1008 - 2025-2-07 =
* FIXED: Minor Bugs
* ADDED: Furniture Shop V2 - Elementor Template Kit - [**Furniture Store V2**](https://demosites.royal-elementor-addons.com/furniture-shop-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Jewelry Store V2 - Elementor Template Kit - [**Jewelry Store V2**](https://demosites.royal-elementor-addons.com/jewelry-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Date Widget

= Royal Elementor Addons v1.7.1007 - 2025-1-12 =
* FIXED: Minor Bugs
* ADDED: Personal Blog V5 - Elementor Template Kit - [**Personal Blog V5**](https://demosites.royal-elementor-addons.com/personal-blog-v5/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.7.1006 - 2024-12-25 =
* FIXED: Instagram Bug

= Royal Elementor Addons v1.7.1005 - 2024-12-18 =
* ADDED: New Year 2025 - Elementor Template Kit - [**New Year V1**](https://demosites.royal-elementor-addons.com/newyear-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Christmas (Shop) - Elementor Templates Kit - [**Christmas V1**](https://demosites.royal-elementor-addons.com/christmas-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Plumbing - Elementor Templates Kit - [**Plumbing V1**](https://demosites.royal-elementor-addons.com/plumbing-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1004 - 2024-11-23 =
* ADDED: Magazine Blog V7 - Elementor Template Kit - [**Magazine V7**](https://demosites.royal-elementor-addons.com/magazine-blog-v7/?ref=rea-wpo-pp-details-tab).
* ADDED: Business Landing Page V2 - Elementor Templates Kit - [**Landing Page Business V2**](https://demosites.royal-elementor-addons.com/landing-page-business-v2/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1003 - 2024-11-20 =
* ADDED: Elementor Fashion (Shop) V4 Template Kit - [**Fashion**](https://demosites.royal-elementor-addons.com/fashion-v4/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1002 - 2024-11-08 =
* ADDED: Elementor Cleaning Services V2 Template Kit - [**Cleaning Services**](https://demosites.royal-elementor-addons.com/cleaning-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Car Repair V2 Template Kit - [**Car Repair**](https://demosites.royal-elementor-addons.com/car-repair-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Financial Services Template Kit - [**Financial Services**](https://demosites.royal-elementor-addons.com/financial-services-v2/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1001 - 2024-10-30 =
* FIXED: Minor Bugs

= Royal Elementor Addons v1.7.1 - 2024-10-18 =
* FIXED: Minor Bugs

== Changelog ===
= Royal Elementor Addons v1.3.985 - 2024-08-26 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.987 - 2024-10-04 =
* ADDED: Elementor Electrician V2 Template Kit - [**Electrician**](https://demosites.royal-elementor-addons.com/electrician-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Book Shop (Shop) V1 Template Kit - [**Book Shop**](https://demosites.royal-elementor-addons.com/book-shop-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Taxonomy List Count Brackets option
* ADDED: Video Tutorial for License Mismatch Solution
* ADDED: Product Mini Cart Hover Color option
* ADDED: Search Notice for Booking and Appointment in Dashboard, Editor Panel and Templates Window.
* FIXED: Form Styler calling undefined wp forms function
* FIXED: Form Builder Shortcodes doesn't work in to, cc and bcc fields of email action
* FIXED: AJAX Search Show Password Protected vulnerability
* FIXED: Magazine Grid Random Query Duplication on Front Page
* FIXED: Flip Box Active Class Issue on Safari Browser
* FIXED: Form Builder Webhook Action Label Issue
* FIXED: Google Maps, Team Member minor vulnerabilities
* FIXED: Post Grid post__not_in parameter passing empty string
* FIXED: Checkout Overflow Hidden Removed
* FIXED: Woo Grid Rating Icons in Incognito when Inline Fonts Activated
* FIXED: Phone Call SVG Hover
* FIXED: Some Controls used In JavaScript not Working due to Optimized Control Loading

= Royal Elementor Addons v1.3.986 - 2024-09-04 =
* FIXED: Countdown, Google Map and Media Grid minor vulnerability issues.
* FIXED: Restrict Show Password Protected Posts Control only to appear for admins (Ajax Search).
* FIXED: Add to Cart widget animation.

= Royal Elementor Addons v1.3.985 - 2024-08-26 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.984 - 2024-08-26 =
* FIXED: Mini Cart Browser Back/Forward arrows bug.
* FIXED: CSV not importing properly in Data Tables widget.
* FIXED: Back to Top Button SVG hover color issue.
* FIXED: Compare table not fetching attributes from different languages.
* FIXED: Mini Cart not expanding fully on sticky header.
* ADDED: Hide All Banners options to admin settings.
* ADDED: Option to display mobile mega menu content by default.

= Royal Elementor Addons v1.3.983 - 2024-08-26 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.982 - 2024-08-19 =
* FIXED: Minor Bugs.
* ADDED: Elementor Software Company V2 Template Kit - [**Software Company**](https://demosites.royal-elementor-addons.com/software-company-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Fashion (Shop) V3 Template Kit - [**Fashion**](https://demosites.royal-elementor-addons.com/fashion-v3/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Wedding V2 Template Kit - [**Wedding**](https://demosites.royal-elementor-addons.com/wedding-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Token Template Kit - [**Token**](https://demosites.royal-elementor-addons.com/token-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.981 - 2024-07-18 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.980 - 2024-07-10 =
* ADDED: Elementor Business Consulting V2 Template Kit - [**Business Consulting**](https://demosites.royal-elementor-addons.com/business-consulting-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Financial Services Template Kit - [**Financial Services**](https://demosites.royal-elementor-addons.com/financial-services-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Hosting Template Kit - [**Hosting**](https://demosites.royal-elementor-addons.com/hosting-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Software Company Template Kit - [**Software Company**](https://demosites.royal-elementor-addons.com/software-company-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.979 - 2024-06-27 =
* FIXED: Minor Bugs.


= Royal Elementor Addons v1.3.978 - 2024-06-26 =
* ADDED: Elementor Graphic Nature Template Kit - [**Graphic Nature**](https://demosites.royal-elementor-addons.com/graphic-nature-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Party Planer Template Kit - [**Party Planner**](https://demosites.royal-elementor-addons.com/party-planner-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Ico Landing Page Template Kit - [**Ico Landing Page**](https://demosites.royal-elementor-addons.com/ico-landing-page-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs.


= Royal Elementor Addons v1.3.977 - 2024-06-06 =
* ADDED: Elementor Car Rental Template Kit - [**Car Rental**](https://demosites.royal-elementor-addons.com/car-rent-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Cleaning Company Template Kit - [**Cleaning Company**](https://demosites.royal-elementor-addons.com/cleaning-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.976 - 2024-05-30 =
* ADDED: Elementor Church V1 Template Kit - [**Church**](https://demosites.royal-elementor-addons.com/church-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.975 - 2024-05-15 =
* ADDED: Elementor Online Course V1 Template Kit - [**Online Course**](https://demosites.royal-elementor-addons.com/online-course-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Electrician V1 Template Kit - [**Electrician**](https://demosites.royal-elementor-addons.com/electrician-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Nail Salon V1 Template Kit - [**Nail Salon**](https://demosites.royal-elementor-addons.com/nail-salon-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.974 - 2024-05-06 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.972 - 2024-04-17 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.971 - 2024-04-12 =
* ADDED: Elementor Travel V3 Template Kit - [**Travel**](https://demosites.royal-elementor-addons.com/travel-v3/?ref=rea-wpo-pp-details-tab).
* ADDED: Digital Marketing V1 One Page Landing Page Template Kit - [**Digital Marketing**](https://demosites.royal-elementor-addons.com/digital-marketing-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Jewelry Store V1 Template Kit - [**Jewelry Store**](https://demosites.royal-elementor-addons.com/jewelry-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.97 - 2024-04-10 =
* Tested up to Latest WP version

= Royal Elementor Addons v1.3.96 - 2024-03-29 =
* ADDED: Elementor Solar Energy Kit V2 - [**Solar Energy Kit**](https://demosites.royal-elementor-addons.com/solar-energy-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Children School V1 - [**Children School Kit**](https://demosites.royal-elementor-addons.com/school-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.95 - 2024-03-22 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.94 - 2024-03-21 =
* ADDED: Magazine Blog V6 Kit - [**Magazine Blog V6**](https://demosites.royal-elementor-addons.com/magazine-blog-v6/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.93 - 2024-03-13 =
* ADDED: Pet Shop Template Kit [**Pet Shop V1**](https://demosites.royal-elementor-addons.com/pet-shop-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.92 - 2024-02-20 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.91 - 2024-02-18 =
* ADDED: Wooshop V2 Template Kit [**Wooshop V2**](https://demosites.royal-elementor-addons.com/shop-wooshop-v2/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.90 - 2024-02-15 =
* ADDED: AI Matrix - Data, Machines & AI Template Kit [**AI Matrix - Data, Machines & AI**](https://demosites.royal-elementor-addons.com/aimatrix-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.89 - 2024-02-08 =
* ADDED: Amazon Product Landing Page Template Kit [**Amazon Product Landing Page**](https://demosites.royal-elementor-addons.com/amazon-landing-page-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.88 - 2024-02-06 =
* FIXED: Minor Bugs.
* ADDED: Designer Bio Template Kit [**Designer Bio**](https://demosites.royal-elementor-addons.com/designer-bio-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.87 - 2024-01-25 =
* ADDED: Developer Portfolio Template Kit [**Developer Portfolio**](https://demosites.royal-elementor-addons.com/developer-portfolio-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.86 - 2024-01-25 =
* ADDED: Personal Blog V4 Template Kit [**Personal Blog V4**](https://demosites.royal-elementor-addons.com/personal-blog-v4/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.85 - 2023-12-27 =
* ADDED: Coming Soon Page Kit [**Coming Soon Kit V1**](https://demosites.royal-elementor-addons.com/coming-soon-pack-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Music Band Template Kit [**Music Band V1**](https://demosites.royal-elementor-addons.com/music-band-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Dental Template Kit [**Dental V1**](https://demosites.royal-elementor-addons.com/dental-v1/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.84 - 2023-12-20 =
* ADDED: Grocery Store V2 Template Kit [**Grocery Store V2**](https://demosites.royal-elementor-addons.com/grocery-store-v2/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.83 - 2023-12-11 =
* ADDED: One Page Digital Agency Kit - [**One Page Digital Agency Kit**](https://demosites.royal-elementor-addons.com/one-page-v2/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.82 - 2023-12-06 =
* ADDED: WPML Multilingual Translation Support for REA Theme Builder Templates.
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.81 - 2023-11-23 =
* ADDED: Barber Shop Kit - [**Barber Shop Kit**](https://demosites.royal-elementor-addons.com/barbershop-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Dance Studio Kit - [**Dance Studio Kit**](https://demosites.royal-elementor-addons.com/dance-studio-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Magazine Blog V4 Kit - [**Magazine Blog V4**](https://demosites.royal-elementor-addons.com/magazine-blog-v4/?ref=rea-wpo-pp-details-tab).
* ADDED: Solar Energy Kit - [**Solar Energy Kit**](https://demosites.royal-elementor-addons.com/solar-energy-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: FAQ, Hero Section and Slider Premade Sections in [**Royal Elementor Library**](https://prnt.sc/HV3jnnFbo8yg).
* TWEAK: Minor tweaks for Elementor Loop Grid / Slider / Carousel Widget.
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.80 - 2023-10-17 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.79 - 2023-10-06 =
* FIXED: Minor Bugs.
* FIXED: Security Issues.

= Royal Elementor Addons v1.3.78 - 2023-09-29 =
* ADDED: Job Listing / Directory Elementor Templates Kit - [**Job Listing Kit**](https://demosites.royal-elementor-addons.com/job-listing-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: 50+ Header and Footer Premade Sections in [**Royal Elementor Library**](https://prnt.sc/aFX-zsDSrX8y).
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.77 - 2023-09-06 =
* ADDED: Real Estate Agency Elementor Templates Kit - [**Real Estate Agency Kit**](https://demosites.royal-elementor-addons.com/realestate-v3/?ref=rea-wpo-pp-details-tab).
* ADDED: Nature - Travel (for beginners) Elementor Templates Kit - [**Nature - Travel**](https://demosites.royal-elementor-addons.com/nature-v2/ref=rea-wpo-pp-details-tab).
* ADDED: Investment Landing Page - Elementor Templates Kit - [**Investment Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-investment-platform-v1/ref=rea-wpo-pp-details-tab).
* ADDED: Startup Landing Page - Elementor Templates Kit - [**Startup Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-startup-v1/ref=rea-wpo-pp-details-tab).
* ADDED: SAAS  Landing Page - Elementor Templates Kit - [**SAAS Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-saas-v1/ref=rea-wpo-pp-details-tab).
* ADDED: Ebook Landing Page - Elementor Templates Kit - [**Ebook Landing Page**](https://demosites.royal-elementor-addons.com/landing-page-ebook-v1/ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.76 - 2023-08-30 =
* ADDED: Digital SEO Marketing Agency Elementor Templates Kit - [**Digital SEO Marketing Agency**](https://demosites.royal-elementor-addons.com/digital-seo-marketing-agency-v2/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.75 - 2023-08-19 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.74 - 2023-08-18 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.73 - 2023-08-10 =
* ADDED: [Advanced Sticky Menu Options](https://prnt.sc/pCVM2ayA_vVV) to create stunning and eye-catching menu effects, check examples (scroll to see menu effects): [Demo 1](https://demosites.royal-elementor-addons.com/fashion-v2/?ref=rea-wpo-pp-details-tab), [Demo 2](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v2/?ref=rea-wpo-pp-details-tab), [Demo 3](https://demosites.royal-elementor-addons.com/personal-blog-v1/?ref=rea-wpo-pp-details-tab), [Demo 4](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v1/?ref=rea-wpo-pp-details-tab), [Demo 5.](https://demosites.royal-elementor-addons.com/construction-v3/?ref=rea-wpo-pp-details-tab)
* ADDED: New [Woocommerce options](https://prnt.sc/TYc4NIi_qjMF).
* ADDED: WPML translation support for Widgets, Template Translation Support is coming soon.
* TESTED: New WP version 6.3.
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.71 - 2023-07-11 =
* ADDED: Business Landing Page - Elementor Templates Kit - [**Landing Page Business**](https://demosites.royal-elementor-addons.com/landing-page-business-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Digital Product Landing Page - Elementor Templates Kit - [**Landing Page Digital Product**](https://demosites.royal-elementor-addons.com/landing-page-digital-product-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Construction v2 Elementor Templates Kit - [**Construction v2**](https://demosites.royal-elementor-addons.com/construction-v2/?ref=rea-wpo-pp-details-tab)
* ADDED: Youtube, Vimeo and Custom Video Support for Advanced Slider Widget (Pro).
* ADDED: Category Filter for Ajax Search Widget (Pro). [**Preview**](https://prnt.sc/1pZSsRHIaFjV)
* ADDED: Category Grid Widget for any type of post types and taxonomies (Expert).
* ADDED: Sorting by Custom Fields for Advanced Post Grid/Slider/Carousel Widget (Pro).
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.70 - 2023-07-01 =
* ADDED: Auto Parts Store Elementor Templates Kit - [**Auto Parts Store**](https://demosites.royal-elementor-addons.com/woo-auto-parts-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.69 - 2023-06-08 =
* ADDED: Home Care v1 Elementor Templates Kit - [**Home Care v1**](https://demosites.royal-elementor-addons.com/home-care-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Fintech v1 Elementor Templates Kit - [**Fintech v1**](https://demosites.royal-elementor-addons.com/fintech-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: One Page Portfolio v2 Elementor Templates Kit - [**One Page Portfolio v1**](https://demosites.royal-elementor-addons.com/portfolio-v2/?ref=rea-wpo-pp-details-tab).
* FIXED: Instagram and Twitter widgets related minor Bugs.

= Royal Elementor Addons v1.3.68 - 2023-05-19 =
* ADDED: Dynamic Tags for widgets,Custom Post Type Sypport (CTP), Custom Fields to build Dynamic Websites.
* ADDED: Wishlist & Compare functionality for Woocommerce. [**Check Demo**](https://demosites.royal-elementor-addons.com/fashion-v2/shop-fashion-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Elementor Form Buidler Widget - [**Form Builder**](https://royal-elementor-addons.com/elementor-form-builder-widget/?ref=rea-wpo-pp-details-tab).
* ADDED: Secondary image on hover for Post Grid/Slider/Carousel and WooCommerce Grid/Slider/Carousel grid widgets.[**Check Demo**](https://demosites.royal-elementor-addons.com/fashion-v2/shop-fashion-v2/?ref=rea-wpo-pp-details-tab).
* ADDED: Construction v3 Elementor Templates Kit - [**Construction v3**](https://demosites.royal-elementor-addons.com/construction-v3/?ref=rea-wpo-pp-details-tab).
* ADDED: Digital Agency v3 Elementor Templates Kit - [**Digital Agency v3**](https://demosites.royal-elementor-addons.com/digitalagency-v3/?ref=rea-wpo-pp-details-tab).
* ADDED: Personal Blog v3 Elementor Templates Kit - [**Personal Blog v3**](https://demosites.royal-elementor-addons.com/personal-blog-v3/?ref=rea-wpo-pp-details-tab).
* ADDED: Ecommerce v1 Elementor Templates Kit - [**Ecommerce v1**](https://demosites.royal-elementor-addons.com/ecommerce-v1/?ref=rea-wpo-pp-details-tab).
* FIXED: Minor Bugs.
* FIXED: Elementor Ajax Search widgets - woocommerce search tempalte related bug.



= Royal Elementor Addons v1.3.67 - 2023-04-03 =
* ADDED: Fashion v2 Elementor Templates Kit - [**Fashion v2**](https://demosites.royal-elementor-addons.com/fashion-v2/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.66 - 2023-03-02 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.65 - 2023-02-27 =
* FIXED: Minor Bugs for Instagram elementor feed widget.
* FIXED: Minor Bugs for the elementor ajax search widget.
* FIXED: Many other small improvements and fixes.
* FIXED: Parallax-related small bugs, now new elementor container supports parallax.
* ADDED: Many premade elementor template pages in the REA library.
* ADDED: Widgets Search and filter buttons in the plugin backend.
* ADDED: Free vs PRO version comparison Table in the plugin backend.
* ADDED: Real Estate v2 Elementor Templates Kit - [**Real Estate**](https://demosites.royal-elementor-addons.com/realestate-v2/?ref=rea-wpo-pp-details-tab).

= Royal Elementor Addons v1.3.64 - 2023-02-10 =
* FIXED: Minor Bugs.

= Royal Elementor Addons v1.3.63 - 2023-02-09 =
* ADDED: Instagram Feed widget.
* ADDED: Twitter Feed widget.
* ADDED: Offcanvas Menu widget (aka side menu).
* ADDED: Lazy Loading for Elementor post grid widgets.
* ADDED: Display Only Scheduled Posts option for Elementor post grid widget.
* ADDED: Vertical Slider Option for Advanced Slider widget.
* ADDED: Option to open grid items in new tab for Elementor post grid, woocommerce grid, and for magazine grid widgets.
* FIXED: Elementor header footer was visible in coming soon and in maintenance mode.
* FIXED: Custom field, Linkable filters and extra text-related issues for Post grid, woocommerce grid and magazine grid.
* ADDED: Responsive Gutter controls for All grids.
* FIXED: One page navigation custom icon issues.
* ADDED: Business Consulting Elementor Templates Kit - [**Business Consulting**](https://demosites.royal-elementor-addons.com/business-consulting-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Car Repair Elementor Templates Kit - [**Car Repair**](https://demosites.royal-elementor-addons.com/car-repair-v1//?ref=rea-wpo-pp-details-tab).


= Royal Elementor Addons v1.3.62 - 2023-01-16 =
* ADDED: Fytness & Gym Elementor Templates Kit - [**Fytness & Gym**](https://demosites.royal-elementor-addons.com/fitness-gym-v1/?ref=rea-wpo-pp-details-tab).


= Royal Elementor Addons v1.3.61 - 2023-01-12 =
* ADDED: Phone field added to elementor Mailchimp widget.
* ADDED: Clear fields option after form submission for elementor Mailchimp widget.
* FIXED: Whatsapp and telegram sharing widgets issues fixed.
* FIXED: Deprecated widgets registration hooks fixed.
* ADDED: Custom CSS turn on/off switcher added in the dashboard extensions panel.
* FIXED: Elementor Magazin grid widget featured image gradient bg color.


= Royal Elementor Addons v1.3.60 - 2022-12-28 =
* ADDED: Hotel Elementor Template Kit [**Hotel**](https://demosites.royal-elementor-addons.com/hotel-v1/?ref=rea-wpo-pp-details-tab).
* ADDED: Premade Pages Templates Library(New requested feature).
* FIXED: Elementor Woocommerce Grid/Slider widget query-related issues.
* FIXED: Elementor mega menu, search widget, and template kit import related Security issues.

= Royal Elementor Addons v1.3.59 - 2022-12-15 =
* FIXED: Category and Tag query issue for elementor post grid widget.

= Royal Elementor Addons v1.3.58 - 2022-12-13 =
* TWEAK: One more improvement for elementor templates Kit import process, about 5-10% faster than in the previous versions. Now the image cropping process only starts after the content import will end. Please note this tweak does not apply to the pre-made elementor widgets importing process.

= Royal Elementor Addons v1.3.57 - 2022-12-09 =
* TWEAK: Improved import time for all elementor templates Kit, about 20% faster than before.
* FIXED: Templates kit import issue for some hosting providers.
* FIXED: Some bug fixes for the elementor toggle widget.

= Royal Elementor Addons v1.3.56 - 2022-12-06 =
* FIXED: Security Related issues.
* TWEAK: Custom Post type support (PRO) for Post grid, Magazin Grid, Content Ticker, and Timeline widget.

= Royal Elementor Addons v1.3.55 - 2022-12-01 =
* ADDED: [**Digital Marketing Agency V2**](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v2/?ref=rea-wpo-pp-details-tab) Elemntor Templates Kit.

= Royal Elementor Addons v1.3.54 - 2022-11-25 =
* Improvements: Huge Performance improvements - All elementor addons and extensions now use 2x less PHP memory.
* Improvements: All OLD Query Controls for Post Grid, Post Slider, Post Carousel, Image Grid, Woocommerce Grid, and Woocommerce Carousel widgets were replaced with Ajax Control Selection.
* ADDED: New feature to Elementor Taxonomy List widget - Extended Filters and Dropdown For Child Categories (Pro).
* FIXED: Minor bugs for Elementor Timeline Widget - Pro query options fixed.
* FIXED: Minor bugs for Elementor Mega Menu widget - Badge Style fixes.
* ADDED: New Control - "Display On Separate Lines" (Pro) for Elementor Post Navigation widget.
* ADDED: New Control - Trim Title & Excerpt By Letter Count for Post grid, Woocommerce grid and Magazin Grid Widgets.(Pro).
* ADDED: New Control - Grid Ordering feature for Post grid and Woocommerce grid(Pro).
* Improvements: All elementor template kits now use 2x less PHP memory in the frontend.
* ADDED: Feature request sections for all Elementor Widgets.
* TWEAK: Show Products Sorting is disabled by default for the Elementor Woocommerce Grid widget.

= Royal Elementor Addons v1.3.53 - 2022-11-08 =
* FIXED: Minor bugs for Elementor Mega Menu widget.
* ADDED: Feature request sections.

= Royal Elementor Addons v1.3.52 - 2022-11-07 =
* FIXED: Minor bugs for Elementor Mega Menu widget.
* FIXED: Minor bugs for Elementor Ajax Search widget.

= Royal Elementor Addons v1.3.51 - 2022-10-31 =
* ADDED: Elementro Mega Menu widget with Off-canvas mobile menu support(PRO).
* ADDED: Elementro Advanced Accordion widget with Search (PRO).
* ADDED: Elementro Image Accordion widget.
* ADDED: Elementro Charts Widget.
* ADDED: Live Ajax Search functionality for Elementor Search Widget. Supports Ajax Search for Woocommerce and for any post type.
* ADDED: Elementor Page List widget for Mega Menu.
* ADDED: Royal Elementor Theme Builder [**Architecture & Interior**](https://demosites.royal-elementor-addons.com/architecture-v2/?ref=rea-wpo-pp-details-tab) Templates Kit.
* FIXED: Minor bugs.

= Royal Elementor Addons v1.3.50 - 2022-09-23 =
* FIXED: Minor bugs.
* ADDED: Some Controlls to the table widgets.


= Royal Elementor Addons v1.3.49 - 2022-09-22 =
* FIXED: Minor bugs.
* ADDED: Elementor Data Table Widget.
* ADDED: Elementor Reading Progress Bar Widget.
* ADDED: Royal Elementor Theme Builder [**Travel Agency**](https://demosites.royal-elementor-addons.com/travel-agency-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.

= Royal Elementor Addons v1.3.48 - 2022-09-13 =
* FIXED: Fixed minor bugs.
* ADDED: Royal Elementor Theme Builder [**Electornic Store**](https://demosites.royal-elementor-addons.com/estore-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.
* ADDED: Royal Elementor Theme Builder [**Food Delivery**](https://demosites.royal-elementor-addons.com/woo-food-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.

= Royal Elementor Addons v1.3.47 - 2022-08-10 =
* FIXED: Fixed minor bugs.

= Royal Elementor Addons v1.3.46 - 2022-08-04 =
* FIXED: Fixed minor woocommerce related bugs.

= Royal Elementor Addons v1.3.45 - 2022-07-027 =
* ADDED: Elementor Woocommerce Builder in Theme Builder Section.
* ADDED: 14+ Elementor Woocommerce Single  Product Builder Widgets like: Add to cart widget, product Price widget, product Breadcrumbs widget (only in PRO) , product Media widget,  product Rating widget and so on...
* ADDED: Elementor Woocommerce Minicart Widgets (Minicart sidebar and other advanced options supported only in PRO).
* ADDED: Elementor Woocommerce Product Filter Widgets (only in PRO).
* ADDED: Elementor Woocommerce Category Grid Widgets (only in PRO).
* ADDED: Elementor Woocommerce My Account Widgets (only in PRO).
* ADDED: Query products by Sale, Featured, Upsell, Cross-sell in Woo Grid/Slider/Carousel widget (only in PRO).
* ADDED: Royal Elementor Woocommerce Builder [**Woo Shop**](https://demosites.royal-elementor-addons.com/wooshop-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.
* ADDED: Royal Elementor Woocommerce Builder [**Fashion**](https://demosites.royal-elementor-addons.com/fashion-v1/?ref=rea-wpo-pp-details-tab) Templates Kit. (only in PRO)
* ADDED: Royal Elementor Woocommerce Builder [**Grocery Store**](https://demosites.royal-elementor-addons.com/grocery-store-v1/?ref=rea-wpo-pp-details-tab) Templates Kit. (only in PRO)
* ADDED: Royal Elementor Woocommerce Builder [**Furniture Store**](https://demosites.royal-elementor-addons.com/furniture-shop-v1/?ref=rea-wpo-pp-details-tab) Templates Kit. (only in PRO)

= Royal Elementor Addons v1.3.44 - 2022-06-03 =
* ADDED: Royal Elementor Theme Builder [**Dark Digital Agency**](https://demosites.royal-elementor-addons.com/digital-agency-dark-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.

= Royal Elementor Addons v1.3.43 - 2022-31-05 =
* NEWS: We are working hard to finish **Woocommerce integration in the theme builder**. We hope the first demo will be available in around **30-40** days.
* ADDED: Royal Elementor Theme Builder [**Digital Marketing Agency**](https://demosites.royal-elementor-addons.com/digital-marketing-agency-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.
* ADDED: Royal Elementor Theme Builder [**One page - Digital Marketing Agency**](https://demosites.royal-elementor-addons.com/one-page-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.
* ADDED: Royal Elementor Theme Builder [**Pet Care**](https://demosites.royal-elementor-addons.com/pet-care-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.
* ADDED: Royal Elementor Theme Builder [**NFT Portfolio**](https://demosites.royal-elementor-addons.com/nft-portfolio-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.
* ADDED: Royal Elementor Theme Builder [**Car Wash**](https://demosites.royal-elementor-addons.com/carwash-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.
* FIXED: Many small bugs.


= Royal Elementor Addons v1.3.42 - 2022-29-04 =
* ADDED: Royal Elementor Theme Builder [**NFT Portfolio**](https://demosites.royal-elementor-addons.com/nft-portfolio-v1/?ref=rea-wpo-pp-details-tab) Templates Kit.

= Royal Elementor Addons v1.3.40 - 2022-19-04 =
* ADDED: Royal Elementor Theme Builder [**Magazine Blog v3**](https://demosites.royal-elementor-addons.com/magazine-blog-v3/?ref=rea-wpo-pp-details-tab) Free Templates Kit.
* ADDED: Royal Elementor Theme Builder [**Video Tutorial**](https://www.youtube.com/watch?v=cwkhwO_rPuo).
* ADDED: Elementor Flip Carousel widget.
* ADDED: Elementor Features List widget.
* ADDED: Elementor Dual Color Heading widget.

= Royal Elementor Addons v1.3.39 - 2022-12-04 =
* FIXED: Elementor Theme Builder minor issues.

= Royal Elementor Addons v1.3.38 - 2022-04-06 =
* ADDED: Elementor Theme Builder. Customize every fundamental part of your WordPress site without coding including your Header, Footer, Archives, Posts, Default Pages, 404 Pages, etc...
* ADDED: Elementor Theme Builder Widgets: Post Title, Post Media, Post Meta, Post Navigation, Post Comments, Post Author, Archive Page Title.
* ADDED: Elementor Theme Builder Demos:
- [**Personal Blog**](https://demosites.royal-elementor-addons.com/personal-blog-v1/?ref=rea-wpo-pp-details-tab)
- [**Magazine Blog v1**](https://demosites.royal-elementor-addons.com/magazine-blog-v1/?ref=rea-wpo-pp-details-tab)
- [**Magazine Blog v2**](https://demosites.royal-elementor-addons.com/magazine-blog-v2/?ref=rea-wpo-pp-details-tab)
- [**Food Blog**](https://demosites.royal-elementor-addons.com/food-blog-v1/?ref=rea-wpo-pp-details-tab)
- [**Travel Blog**](https://demosites.royal-elementor-addons.com/travel-blog-v1/?ref=rea-wpo-pp-details-tab)

= Royal Elementor Addons v1.3.37 - 2022-04-04 =
* FIXED: Elementor Header, Elementor Footer, Elementor Popup import issue.

= Royal Elementor Addons v1.3.36 - 2022-28-03 =
* FIXED: Removed Reset CSS code which gives ability to adjust content better.

= Royal Elementor Addons v1.3.34 - 2022-18-03 =
* FIXED: Unordered and Ordered Lists spacing issue, also Headings size issue fixed in Royal Addons for Elementor.

= Royal Elementor Addons v1.3.33 - 2022-4-03 =
* ADDED: Travel Blogger & Influencer Elementor Template Kit.
* ADDED: Freemius SDK update to 2.4.3.

= Royal Elementor Addons v1.3.32 - 2022-24-02 =
* ADDED: Digital Agency Elementor Template Kit.
* ADDED: Video Tutorials to Particles Effects addon for Elementor and Sticky Section addon Elementor.

= Royal Elementor Addons v1.3.30 - 2022-14-02 =
* ADDED: Lawyer Elementor Template Kit.
* ADDED: Elementor Timeline Widget Predefined Styles.
* FIX: Minor but essential Bugs.

= Royal Elementor Addons v1.3.29 - 2022-7-02 =
* FIX: Elementor Sticky Header conflict with other Elementor Addons.
* FIX: Minor but essential Bugs.

= Royal Elementor Addons v1.3.28 - 2022-2-02 =
* FIX: Minor Posts Timeline Bugs.

= Royal Elementor Addons v1.3.27 - 2022-31-01 =
* ADDED: Photographer Portfolio Elementor Template Kit Dark.
* ADDED: Photographer Portfolio Elementor Template Kit Light.
* ADDED: Wine Bar Elementor Template Kit.
* ADDED: Elementor Timeline Widget.
* FIX: Elementor Template kit causes daouble header issue on some popular themes.
* FIX: Minor but essential Bugs.

= Royal Elementor Addons v1.3.26 - 2022-21-01 =
* ADDED: Pizza Restaurant Elementor Template.
* ADDED: Royal Elementor Widget Pro Features List Section.
* FIX: Minor but essential Bugs.

= Royal Elementor Addons v1.3.25 - 2021-12-24 =
* ADDED: Elementor Templates Kit Library (Elementor Starter Sites).
* FIX: Minor but essential Bugs.

= Royal Elementor Addons v1.3.23 - 2021-12-09 =
* FIX: Minor but essential Bugs.

= Royal Elementor Addons v1.3.22 - 2021-12-03 =
* FIX: Elementor Pricing Table widget Button link is now clickable.
* FIX: Custom Post Types Elementor support option issue.
* ADDED: New Predefined Styles to Royal Elementor Addons Library.
* ADDED: Option to show Elementor Header and Footer on Elementor Canvas pages.
* ADDED: Youtube Video Tutorial link to Elementor OnePage Navigation Widget.

= Royal Elementor Addons v1.3.21 - 2021-11-22 =
* FIX: Minor but essential Bugs.
* ADDED: White Label Branding (Supported in PRO verison)

= Royal Elementor Addons v1.3.2 - 2021-11-19 =
* FIX: Elementor Text widget bullet list issue.
* FIX: Elementor Team member widget description option doesn't accept HTML tags.
* FIX: Elementor Sharing widget WhatsApp sharing issue.

= Royal Elementor Addons v1.3 - 2021-10-29 =
* ADDED: Elementor Header and Footer Builder.
* ADDED: Elementor Popups (Elementor Modal Popups) Builder. Offer Sales Banners, Subscriptions Banners, GDPR Cookie Consent & Compliance Notice, Cookie Notice, Age Verification. With Exit Intent query parameter targeting (only in PRO).
* ADDED: Elementor Predefined Styles for Popups and various Royal Elementor Addons Widgets.
* ADDED: Elementor Particles Effect to the section options.
* ADDED: Elementor Parallax Background Effect to the section options.
* ADDED: Elementor Parallax Multi Layer Effect to the section options.
* ADDED: Elementor Custom CSS option to the Widgets, Columns and Sections.
* ADDED: Freemius has been integrated.
* FIX: Elementor Phone Call Widget has no icon in editor.
* FIX: Elementor Flip Box front button z-index issue.

= Royal Elementor Addons v1.2 - 2021-09-24 =
* FIX: Elementor Grid Widget responsive column issues.
* FIX: Elementor Slider Widget responsive column issues.
* FIX: Elementor Content Ticker Widget responsive column issues.
* FIX: Elementor Testimonial Carousel Widget responsive column issues.
* FIX: Added support for Elementor beta breakpoints.

= Royal Elementor Addons v1.0 - 2021-08-14 =
* Initial Release.