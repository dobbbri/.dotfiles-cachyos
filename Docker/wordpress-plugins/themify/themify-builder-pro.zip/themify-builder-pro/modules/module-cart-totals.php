<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Module Name: Cart Totals
 * Description: 
 */
class TB_Cart_Totals_Module extends Themify_Builder_Component_Module {

	public static function init():void{
	}

	public static function is_available():bool{
		return themify_is_woocommerce_active();
	}

	public static function get_module_name():string {
		return __('Cart Totals', 'tbp');
	}

	public static function get_module_icon():string {
		return 'receipt';
	}

	public static function get_js_css():array{
		return array(
			'ver' => TBP_VER,
			'css' => TBP_WC_CSS_MODULES . 'cart-totals'
		);
	}

	/**
	 * Render plain content for static content.
	 */
	public static function get_static_content(array $module):string {
		return '';
	}

	public static function get_translatable_text_fields( $module ) : array {
		return [ 'lbl_heading', 'lbl_stotals', 'lbl_shipping', 'lbl_totals' ];
	}

    public static function get_styling_image_fields() : array {
        return [];
    }
}