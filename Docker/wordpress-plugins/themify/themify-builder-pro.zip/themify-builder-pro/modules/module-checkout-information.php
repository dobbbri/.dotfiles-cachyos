<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Module Name: Checkout Information
 * Description: 
 */
class TB_Checkout_Information_Module extends Themify_Builder_Component_Module {

	public static function init():void{
	}

	public static function is_available():bool{
		return themify_is_woocommerce_active();
	}

	public static function get_module_name():string {
		return __('Checkout Information', 'tbp');
	}

	public static function get_module_icon():string {
		return 'info-alt';
	}

	public static function get_js_css():array{
		return array(
		);
	}

	/**
	 * Render plain content for static content.
	 */
	public static function get_static_content(array $module):string {
		return '';
	}

    public static function get_styling_image_fields() : array {
        return [];
    }
}