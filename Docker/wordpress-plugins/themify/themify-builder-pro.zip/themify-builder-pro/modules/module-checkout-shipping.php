<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Module Name: Checkout Shipping
 * Description: 
 */
class TB_Checkout_Shipping_Module extends Themify_Builder_Component_Module {

	public static function init():void{
	}

	public static function is_available():bool{
		return themify_is_woocommerce_active();
	}

	public static function get_module_name():string {
		return __('Checkout Shipping', 'tbp');
	}

	public static function get_module_icon():string {
		return 'truck';
	}

	public static function get_js_css():array{
		return array(
		);
	}

	/**
	 * Render plain content for static content.
	 */
	public static function get_static_content(array $module):string {
		return '';
	}

	public static function get_translatable_text_fields( $module ) : array {
		return [ 'lbl_heading', 'lbl_heading2' ];
	}

    public static function get_styling_image_fields() : array {
        return [];
    }
}