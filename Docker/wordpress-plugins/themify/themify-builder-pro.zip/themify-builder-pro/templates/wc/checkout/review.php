<?php if ( $args['lbl_heading'] !== '' ) : ?><<?php echo $args['title_tag']; ?> id="order_review_heading" class="tbp_order_review_heading"><?php if ( $args['i_heading'] !== '' ) : ?><em><?php echo themify_get_icon( $args['i_heading'] ); ?></em> <?php endif; ?><?php echo esc_html( $args['lbl_heading'] ); ?></<?php echo $args['title_tag']; ?>><?php endif; ?>

<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

<div id="order_review" class="woocommerce-checkout-review-order">
    <?php do_action( 'woocommerce_checkout_order_review' ); ?>
    <?php woocommerce_order_review(); ?>
</div>

<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
