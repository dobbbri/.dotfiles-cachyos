<div class="woocommerce-additional-fields">
	<?php do_action( 'woocommerce_before_order_notes', $args['checkout'] ); ?>

	<?php if ( apply_filters( 'woocommerce_enable_order_notes_field', 'yes' === get_option( 'woocommerce_enable_order_comments', 'yes' ) ) ) : ?>

        <?php if ( $args['lbl_heading'] !== '' ) : ?><<?php echo $args['title_tag']; ?> class="tbp_checkout_additional_fields_title"><?php if ( $args['i_heading'] !== '' ) : ?><em><?php echo themify_get_icon( $args['i_heading'] ); ?></em> <?php endif; ?><?php echo esc_html( $args['lbl_heading'] ); ?></<?php echo $args['title_tag']; ?>><?php endif; ?>

		<div class="woocommerce-additional-fields__field-wrapper">
			<?php foreach ( $args['checkout']->get_checkout_fields( 'order' ) as $key => $field ) : ?>
				<?php woocommerce_form_field( $key, $field, $args['checkout']->get_value( $key ) ); ?>
			<?php endforeach; ?>
		</div>

	<?php endif; ?>

	<?php do_action( 'woocommerce_after_order_notes', $args['checkout'] ); ?>
</div>
