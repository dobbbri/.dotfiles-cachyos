<?php

$checkout = WC()->checkout();
remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
remove_action( 'woocommerce_checkout_billing', array( $checkout, 'checkout_form_billing' ) );
remove_action( 'woocommerce_checkout_shipping', array( $checkout, 'checkout_form_shipping' ) );
remove_action( 'woocommerce_checkout_billing', array( $checkout, 'checkout_form_shipping' ) );

do_action( 'woocommerce_before_checkout_form', $checkout );

Themify_Enqueue_Assets::addPrefetchJs( TBP_URL . 'public/js/modules/checkout.js', TBP_VER );
Themify_Enqueue_Assets::add_js( 'tbp-checkout', TBP_URL . 'public/js/modules/checkout.js', [ 'wc-checkout' ], TBP_VER, true );
?>

<style>
form.checkout > .woocommerce-NoticeGroup-checkout { display: none }
</style>

<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

    <?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>