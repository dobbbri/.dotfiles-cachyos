<?php

$checkout = WC()->checkout();
?>

    <?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
