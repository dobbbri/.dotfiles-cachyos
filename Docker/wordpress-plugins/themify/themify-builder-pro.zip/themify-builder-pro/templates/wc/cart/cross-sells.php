<?php if ( $args['cross_sells'] ) : ?>

    <?php if ( ! empty( $args['heading'] ) ) {
        $title_tag = esc_attr( $args['title_tag'] );
        echo '<', $title_tag, ' class="tbp_crosssell_heading">', esc_html( $args['heading'] ), '</', $title_tag, '>';
    }
    ?>

    <?php woocommerce_product_loop_start(); ?>

        <?php foreach ( $args['cross_sells'] as $cross_sell ) : ?>

            <?php
                $post_object = get_post( $cross_sell->get_id() );

                setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found

                wc_get_template_part( 'content', 'product' );
            ?>

        <?php endforeach; ?>

    <?php woocommerce_product_loop_end(); ?>

	<?php
endif;

wp_reset_postdata();